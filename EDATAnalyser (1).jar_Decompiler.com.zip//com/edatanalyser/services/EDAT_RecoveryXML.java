package com.edatanalyser.services;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class EDAT_RecoveryXML extends EDAT_AnalyserUtils {
   Document doc = null;
   Element rootElement = null;
   static EDAT_RecoveryXML instance = null;
   static String recoveryFileXML = "";
   static String recoveryFilePath = "";

   public EDAT_RecoveryXML() {
      try {
         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
         File f = new File(recoveryFileXML);
         if (!f.exists()) {
            this.doc = dBuilder.newDocument();
            this.rootElement = this.doc.createElement("Recovery");
            this.doc.appendChild(this.rootElement);
         } else {
            this.doc = dBuilder.parse(recoveryFileXML);
            this.rootElement = this.doc.getDocumentElement();
         }
      } catch (Exception var4) {
         EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : Exception in EDAT_RecoveryXML class : " + var4.getMessage());
         System.out.println("EDAT_RecoveryXML : Exception in EDAT_RecoveryXML class");
      }

   }

   public String getObjectID(String strType, String strOperation) throws Exception {
      strType = strType.replaceAll(" ", "");
      String strObjectID = "";

      try {
         NodeList elemTypeList = this.doc.getElementsByTagName(strType);
         if (elemTypeList.getLength() > 0) {
            Node typenode = elemTypeList.item(0);
            if (typenode != null) {
               Element currentelement = (Element)typenode;
               NodeList lstOper = currentelement.getElementsByTagName(strOperation);
               if (lstOper.getLength() > 0) {
                  Node node = lstOper.item(0);
                  currentelement = (Element)node;
                  if (currentelement.getElementsByTagName("id").getLength() > 0) {
                     strObjectID = currentelement.getElementsByTagName("id").item(0).getTextContent();
                  }
               }
            }
         }
      } catch (Exception var9) {
         EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : getObjectID --Exception in getObjectID method :  " + var9.getMessage());
         throw new Exception("EDAT_RecoveryXML : Exception while getting ObjectId :  " + var9.getMessage());
      }

      EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : getObjectID : " + strObjectID);
      return strObjectID;
   }

   public static EDAT_RecoveryXML getInstance() {
      if (instance == null) {
         try {
            recoveryFileXML = EDAT_DB_Analyser.objAnlayserConfig.getDecodedPropertiesPath() + File.separator + "config" + File.separator + "Recovery.xml";
            instance = new EDAT_RecoveryXML();
         } catch (Exception var1) {
            EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : getInstance : Exception in getInstance method :  " + var1.getMessage());
            System.out.println("EDAT_RecoveryXML : Exception while getting Instance :  " + var1.getMessage());
         }
      }

      return instance;
   }

   public void AddOperation(String strType, String strOperation, String strID, String strRev, String strOriginated) throws Exception {
      strType = strType.replaceAll(" ", "");
      EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : AddOperation : strType --->>>> : " + strType);
      EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : AddOperation : strOperation --->>>> : " + strOperation);
      EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : AddOperation : strID --->>>> : " + strID);
      EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : AddOperation : strRev --->>>> : " + strRev);
      EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : AddOperation : strOriginated --->>>> : " + strOriginated);
      Node nodeType = null;
      Element elementType = null;

      try {
         NodeList elemTypeList = this.doc.getElementsByTagName(strType);
         if (elemTypeList.getLength() == 0) {
            elementType = this.doc.createElement(strType);
            this.rootElement.appendChild(elementType);
         } else {
            elementType = (Element)elemTypeList.item(0);
         }

         NodeList elemOperationList = elementType.getElementsByTagName(strOperation);
         Element elementOperation;
         if (elemOperationList.getLength() == 0) {
            elementOperation = this.doc.createElement(strOperation);
            Element elementId = this.doc.createElement("id");
            elementId.setTextContent(strID);
            Element elementRev = this.doc.createElement("revision");
            elementRev.setTextContent(strRev);
            Element elementOriginatedDate = this.doc.createElement("originated");
            elementOriginatedDate.setTextContent(strOriginated);
            elementOperation.appendChild(elementId);
            elementOperation.appendChild(elementRev);
            elementOperation.appendChild(elementOriginatedDate);
            elementType.appendChild(elementOperation);
            this.rootElement.appendChild(elementType);
         } else {
            Node nodeOperation = (Element)elemOperationList.item(0);
            elementOperation = (Element)nodeOperation;
            elementOperation.getElementsByTagName("id").item(0).setTextContent(strID);
            elementOperation.getElementsByTagName("revision").item(0).setTextContent(strRev);
            elementOperation.getElementsByTagName("originated").item(0).setTextContent(strOriginated);
            elementType.appendChild(elementOperation);
            this.rootElement.appendChild(elementType);
         }

      } catch (Exception var15) {
         EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : AddOperation : Exception in AddOperation method :  " + var15.getMessage());
         throw new Exception("EDAT_RecoveryXML : Exception while Adding Opertaion :  " + var15.getMessage());
      }
   }

   public void SaveRecoveryXML() {
      TransformerFactory transformerFactory = TransformerFactory.newInstance();

      try {
         Transformer transformer = transformerFactory.newTransformer();
         transformer.setOutputProperty("indent", "yes");
         transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
         DOMSource source = new DOMSource(this.doc);
         StreamResult result = new StreamResult(new File(recoveryFileXML));
         transformer.transform(source, result);
      } catch (TransformerConfigurationException var5) {
         EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : SaveRecoveryXML --- Exception in SaveRecoveryXML method : " + var5.getMessage());
         System.out.println("EDAT_RecoveryXML : Exception while saving Recovery XML file :  " + var5.getMessage());
      } catch (TransformerException var6) {
         EDAT_DB_Analyser.printTrace("EDAT_RecoveryXML : SaveRecoveryXML --- Exception in SaveRecoveryXML method : " + var6.getMessage());
         System.out.println("EDAT_RecoveryXML : Exception while saving Recovery XML file :  " + var6.getMessage());
      }

   }
}
