package com.edatanalyser.services;

import com.dassault.activation.JDKFiveActivation;
import com.edatanalyser.dao.EDAT_AnalyserBusinessDAO;
import com.edatanalyser.dao.EDAT_AnalyserConfigurationDAO;
import com.edatanalyser.mapping.EDAT_AnalyserBusinessInterface;
import com.edatanalyser.mapping.EDAT_AnalyserConfigurationInterface;
import com.edatxflowlogger.XFlowLogger;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.Map.Entry;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import logger.DTKLogger;
import matrix.db.Context;
import matrix.db.MQLCommand;
import matrix.util.StringList;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class EDAT_DB_Analyser extends EDAT_AnalyserUtils {
   private Properties properties = null;
   private List<String> rootList = new ArrayList();
   static XFlowLogger xMLLogger = XFlowLogger.getInstance("config.xml", "Analyzer");
   Map<String, String> firstRevisions = new HashMap();
   String typepath = "";
   String strPath = "";
   private int iAssemblyLevel = 0;
   public Map<String, HashMap<String, String>> mFinal = new LinkedHashMap();
   List<String> listTypeData = new ArrayList();
   StringList slObjectSelects = new StringList();
   String strRelPattern = new String();
   int fileCount = 0;
   String baseFolder = "";
   String propertiesPath;
   private boolean isForceCreateDir = true;
   public String recoveryId = "";
   public String recoveryRev = "";
   public String recoveryOriginatedDate = "";
   public String strAnalysingType = "";
   public String operation = "FirstRev";
   boolean splitLater = false;
   public String flag;
   public MapList mlResults = new MapList();
   Document doc = null;
   long xFlowStartTime = System.currentTimeMillis();
   StringList lstTypes = new StringList();
   private List<String> allCATPartsBusId = new ArrayList();
   private List<String> allCATProductsBusId = new ArrayList();
   private List<String> AnalyzeCATDrawings = new ArrayList();
   private Map<String, List> sCATPart = new HashMap();
   private List<String> firstRevParts = new ArrayList();
   private List<String> restRevParts = new ArrayList();
   private Map<Integer, HashMap> firstRevLevel = new HashMap();
   private Map<Integer, HashMap> restRevLevel = new HashMap();
   private List<String> firstRevProducts = new ArrayList();
   private List<String> restRevProducts = new ArrayList();
   private Map<String, List> sCATDrawing = new HashMap();
   private List<String> firstRevDrawing = new ArrayList();
   private List<String> restRevDrawing = new ArrayList();
   public double threshold = 1.0D;
   StringList slProcessedList = new StringList();
   StringList lstSkipObjects = new StringList();
   public static Boolean traceOn = false;
   String invalidChar = "";
   List<Character> invalidCharLst = new ArrayList();
   static EDAT_AnalyserConfigurationInterface objAnlayserConfig = new EDAT_AnalyserConfigurationDAO();
   EDAT_RecoveryXML recoveryXML = null;
   Map<String, List<String>> dbMap = null;
   String strInvalidNamesPath = null;
   String strMissingFilesPath = null;
   String strHavingSpaceNamePath = null;
   String strHavingMoreThan100CharFileNamePath = null;
   String ObjectHavingMultiplefilesPath = null;
   String Exportpathtxt = null;
   String ExportPathtxtDir = null;
   StringList ExportPathList = new StringList();
   String strHavingMoreThan256CharDescriptionPath = null;
   String strInvalidDescriptionPath = null;
   String strComponentAssemblyNameMatchesPath = null;
   String strDecVersionPath = null;
   String strCATIAEmbeddedComponentsPath = null;
   DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
   boolean isUpdateMode = false;
   boolean isSelectiveMode = false;

   public String getParamaterValueFromXML(Document doc, String tagName) {
      String nodeValue = null;

      try {
         NodeList nodeList = doc.getElementsByTagName(tagName);

         for(int i = 0; i < nodeList.getLength(); ++i) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == 1) {
               nodeValue = node.getTextContent();
            }
         }
      } catch (Exception var7) {
         var7.getMessage();
      }

      return nodeValue;
   }

   private Document readConfigXMLDoc(Context context) {
      try {
         objAnlayserConfig.setDecodedPropertiesPath();
         String path = objAnlayserConfig.getDecodedPropertiesPath() + File.separator + "config" + File.separator + "config.xml";
         File file = new File(path);
         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         DocumentBuilder builder = factory.newDocumentBuilder();
         this.doc = builder.parse(file);
         this.doc.getDocumentElement().normalize();
         objAnlayserConfig.setFullMode(this.getParamaterValueFromXML(this.doc, "FullMigrationScope"));
         objAnlayserConfig.setCADType(this.getParamaterValueFromXML(this.doc, "CADType"));
         objAnlayserConfig.setRecoveryMode(this.getParamaterValueFromXML(this.doc, "RecoveryMode"));
         objAnlayserConfig.setReleasedState(this.getParamaterValueFromXML(this.doc, "DecMaturityStates"));
         objAnlayserConfig.setMaturity(this.getParamaterValueFromXML(this.doc, "Maturity"));
         objAnlayserConfig.setGrtThan15x(this.getParamaterValueFromXML(this.doc, "IsVersionGreaterThan15x"));
         objAnlayserConfig.setCloudMigration(this.getParamaterValueFromXML(this.doc, "CloudMigration"));
         objAnlayserConfig.setLotStartDateTime(this.getParamaterValueFromXML(this.doc, "LotStartDateTime"));
         objAnlayserConfig.setLotEndDateTime(this.getParamaterValueFromXML(this.doc, "LotEndDateTime"));
         objAnlayserConfig.setBaseDirectory(this.getParamaterValueFromXML(this.doc, "BaseDirectory"));
         objAnlayserConfig.setDashboard(this.getParamaterValueFromXML(this.doc, "Dashboard"));
         objAnlayserConfig.setLstImmediateTypes();
         objAnlayserConfig.setLstNonImmediateTypes();
         objAnlayserConfig.setSelectiveMode(this.getParamaterValueFromXML(this.doc, "SelectiveMode"));
         this.threshold = Double.parseDouble(this.getParamaterValueFromXML(this.doc, "MaxRootsInOneFile"));
         this.recoveryXML = EDAT_RecoveryXML.getInstance();
         String strLogPath = this.getParamaterValueFromXML(this.doc, "LogPath");
         if (UIUtil.isNotNullAndNotEmpty(strLogPath)) {
            DTKLogger.GetLogger("Analyzer", strLogPath);
            traceOn = DTKLogger.isTraceOn();
            System.out.println("traceOn-----" + traceOn);
         }

         if ("ON".equals(objAnlayserConfig.getCloudMigration()) && "OFF".equals(objAnlayserConfig.getFullMode())) {
            this.threshold = 1.0D;
            File fileFailureList = new File(objAnlayserConfig.getDecodedPropertiesPath() + File.separator + "config" + File.separator + "FailureCase.txt");
            if (fileFailureList.exists() && fileFailureList.length() != 0L) {
               this.failDataClearance(context, fileFailureList);
            }
         }

         String strSkipObject = this.getParamaterValueFromXML(this.doc, "SkipObjects");
         if (UIUtil.isNotNullAndNotEmpty(strSkipObject) && "ON".equalsIgnoreCase(strSkipObject)) {
            this.readSkipObjectsFile(strSkipObject);
         }

         String decautonamevalue = this.getParamaterValueFromXML(this.doc, "DECAutoName");
         if (UIUtil.isNotNullAndNotEmpty(decautonamevalue)) {
            EDAT_AnalyserBusinessDAO.decautonameflag = decautonamevalue;
         }

         printTrace("EDAT_DB_Analyser : readconfigXMLDOC: decautoname : " + decautonamevalue);
      } catch (Exception var9) {
         System.out.println("Please check the configuration file, all required tag should be present" + var9.getMessage());
      }

      return this.doc;
   }

   public void getConfigData(Context context) {
      try {
         this.readConfigXMLDoc(context);
         printTrace("EDAT_DB_Analyser : getConfigData : reading  readConfigXMLDoc is done--->");
         String pathSep = this.getPathSeperator(objAnlayserConfig.getBaseDirectory());
         this.strInvalidNamesPath = objAnlayserConfig.getBaseDirectory() + pathSep + "InvalidFileName.txt";
         this.strMissingFilesPath = objAnlayserConfig.getBaseDirectory() + pathSep + "EmptyFileName.txt";
         this.strHavingSpaceNamePath = objAnlayserConfig.getBaseDirectory() + pathSep + "HavingSpaceInNamesOrFileName.txt";
         this.strHavingMoreThan100CharFileNamePath = objAnlayserConfig.getBaseDirectory() + pathSep + "HavingNamesOrFileNameMoreThan100Char.txt";
         this.ObjectHavingMultiplefilesPath = objAnlayserConfig.getBaseDirectory() + pathSep + "CadObjectHavnigMoreThanOneFile.txt";
         this.Exportpathtxt = objAnlayserConfig.getBaseDirectory() + pathSep + "ExportPaths" + pathSep + "Export_Paths_";
         this.ExportPathtxtDir = objAnlayserConfig.getBaseDirectory() + pathSep + "ExportPaths";
         this.strHavingMoreThan256CharDescriptionPath = objAnlayserConfig.getBaseDirectory() + pathSep + "DescriptionHavingMoreThan256Char.txt";
         this.strInvalidDescriptionPath = objAnlayserConfig.getBaseDirectory() + pathSep + "InvalidDescription.txt";
         this.strComponentAssemblyNameMatchesPath = objAnlayserConfig.getBaseDirectory() + pathSep + "ComponentAssemblyNameMatches.txt";
         this.strDecVersionPath = objAnlayserConfig.getBaseDirectory() + pathSep + "DEC_Server_Version.txt";
         this.strCATIAEmbeddedComponentsPath = objAnlayserConfig.getBaseDirectory() + pathSep + "CATIA_Embedded_Components.txt";
         printTrace("EDAT_DB_Analyser : getConfigData : ---> " + objAnlayserConfig.getFullMode());
         if (!"ON".equals(objAnlayserConfig.getFullMode())) {
            printTrace("EDAT_DB_Analyser : getConfigData ----> Delta Migration Running");
            EDAT_DBService dbService = new EDAT_DBService();
            this.dbMap = dbService.getDetailsFromTable(context);
            printTrace("EDAT_DB_Analyser : getConfigData ----> dbMap  :" + this.dbMap);
            this.isUpdateMode = true;
         }

         printTrace("EDAT_DB_Analyser : getConfigData : Selective Mode ---> " + objAnlayserConfig.getSelectiveMode());
         if ("ON".equals(objAnlayserConfig.getSelectiveMode())) {
            printTrace("EDAT_DB_Analyser : getConfigData ----> Selective Migration Running");
            this.isSelectiveMode = true;
         }

         printTrace("EDAT_DB_Analyser : getConfigData : Properties from Analyserconfig.xml --->> strFullMode : [ " + objAnlayserConfig.getFullMode() + "] " + "and strSelectiveMode : [" + objAnlayserConfig.getSelectiveMode() + "] and strCADType : [ " + objAnlayserConfig.getCADType() + "] and recoveryMode : [ " + objAnlayserConfig.getRecoveryMode() + "] and releasedState : [ " + objAnlayserConfig.getReleasedState() + " ] and strMaturity : [ " + objAnlayserConfig.getMaturity() + "] " + "and strCloud : [ " + objAnlayserConfig.getCloudMigration() + "]");
      } catch (Exception var4) {
         printTrace("EDAT_DB_Analyser : getConfigData ---> IOException :  " + var4.getMessage());
         System.out.println("EDAT_DB_Analyser : Error occurred in while properties from analyser config file  : " + var4.getMessage());
      }

   }

   public String getServerVersion(Context context) {
      String version = null;
      MQLCommand mqlCommand = null;

      try {
         mqlCommand = new MQLCommand();
         mqlCommand.open(context);
         boolean success = mqlCommand.executeCommand(context, "version;");
         if (success) {
            version = mqlCommand.getResult().trim();
         } else {
            System.err.println("Error executing MQL version command: " + mqlCommand.getError());
         }

         mqlCommand.close(context);
      } catch (Exception var5) {
         var5.printStackTrace();
      }

      return version;
   }

   private void writeDecVersionToFile(Context context, String decVersion) {
      String strbaseDir = objAnlayserConfig.getBaseDirectory();
      File directory = new File(strbaseDir);
      if (!directory.exists() && !directory.mkdirs()) {
         System.err.println("ERROR: Failed to create directory: " + strbaseDir);
      } else {
         File file = new File(this.strDecVersionPath);

         try {
            if (!file.exists() && !file.createNewFile()) {
               System.err.println("ERROR: Failed to create file: " + this.strDecVersionPath);
               return;
            }

            try {
               Throwable var6 = null;
               Object var7 = null;

               try {
                  BufferedWriter writer = new BufferedWriter(new FileWriter(file));

                  try {
                     writer.write("DEC Server Version: " + decVersion);
                     writer.newLine();
                  } finally {
                     if (writer != null) {
                        writer.close();
                     }

                  }
               } catch (Throwable var18) {
                  if (var6 == null) {
                     var6 = var18;
                  } else if (var6 != var18) {
                     var6.addSuppressed(var18);
                  }

                  throw var6;
               }
            } catch (IOException var19) {
               System.err.println("ERROR: IOException while writing to file: " + this.strDecVersionPath);
               var19.printStackTrace();
            }
         } catch (IOException var20) {
            System.err.println("ERROR: Failed to create file or directory: " + this.strDecVersionPath);
            var20.printStackTrace();
         }

      }
   }

   public void processAnalyingData(Context context, String[] args) {
      String decVersion = this.getServerVersion(context);
      if (decVersion != null) {
         System.out.println("DEC Server Version: " + decVersion);
      } else {
         System.out.println("Failed to retrieve DEC server version.");
      }

      System.out.println("EDAT DTK Analyser Build Date: 30th April 2025 EDAT 2025 Refresh_GA.");
      printTrace("EDAT DTK Analyser Build Date: 30th April 2025 EDAT 2025 Refresh_GA.");
      printTrace("EDAT_DB_Analyser : processAnalyingData ---> Start of the method");
      String strStartDate = this.currentDateTime();
      xMLLogger.AddNodewithTextValue("StartDateTime", strStartDate);
      xMLLogger.SaveXFlowXML();
      if (!checkLicense()) {
         System.out.println("License not granted");
      } else {
         System.out.println("License granted");
         this.getConfigData(context);

         String strEndtDate;
         try {
            this.lstTypes = this.readDocumentInputType();
            String strBaseDir = objAnlayserConfig.getBaseDirectory();
            this.validateDirectory(strBaseDir);
            this.validateDirectory(this.ExportPathtxtDir);
            this.writeDecVersionToFile(context, decVersion);
            EDAT_AnalyserBusinessInterface obj = new EDAT_AnalyserBusinessDAO();
            String command = obj.getRootQuery();
            String validLotDates = obj.getLOTDateTimeWhereClause(objAnlayserConfig, xMLLogger);

            for(int i = 0; i < this.lstTypes.size(); ++i) {
               this.strAnalysingType = (String)this.lstTypes.get(i);
               this.firstRevisions.clear();
               this.listTypeData.clear();
               printTrace(" processAnalyingData : Analysing type :  " + this.strAnalysingType);
               System.out.println(" Analysing CAD type :  " + this.strAnalysingType);
               StringBuffer tempWhere = new StringBuffer();
               if (validLotDates.equals("invalid")) {
                  return;
               }

               tempWhere.append("(").append(validLotDates);
               tempWhere.append(obj.getCadBasedWhereClause(this.strAnalysingType, objAnlayserConfig.getCADType(), objAnlayserConfig.isGrtThan15x(), objAnlayserConfig.getReleasedState())).append(")");
               if ("ON".equals(objAnlayserConfig.getCloudMigration()) && UIUtil.isNotNullAndNotEmpty(objAnlayserConfig.getMaturity())) {
                  tempWhere.append(" && current =='" + objAnlayserConfig.getMaturity().trim() + "'");
               }

               printTrace("EDAT_DB_Analyser :  processAnalyingData : strAnalysingType  : " + this.strAnalysingType + " and mql condition : " + tempWhere.toString());
               obj.fetchServerDataBased(context, this.strAnalysingType, command, tempWhere.toString(), strBaseDir, objAnlayserConfig.isGrtThan15x(), objAnlayserConfig.getCADType());
               strEndtDate = this.currentDateTime();
               printTrace("EDAT_DB_Analyser :  processAnalyingData : strEndtDate--> " + strEndtDate);
               this.ExportPathList.clear();
               this.postProcessingAnalyserData(context, strBaseDir);
               String Exporttypename = this.strAnalysingType.replaceAll(" ", "_");
               this.writeAnalysedFile(this.ExportPathList, this.Exportpathtxt + Exporttypename + ".txt");
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstInvalidNames, this.strInvalidNamesPath);
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstMissingFilesNames, this.strMissingFilesPath);
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstHavingSpaceFilesNames, this.strHavingSpaceNamePath);
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstFilenameLenGT100Char, this.strHavingMoreThan100CharFileNamePath);
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstHavingMultipleFilesAttached, this.ObjectHavingMultiplefilesPath);
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstInvalidDescription, this.strInvalidDescriptionPath);
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstDescriptionLenGT256Char, this.strHavingMoreThan256CharDescriptionPath);
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstComponentAssemblyNameMatches, this.strComponentAssemblyNameMatchesPath);
               this.writeAnalysedFile(EDAT_AnalyserBusinessInterface.lstCATIAEmbeddedComponents, this.strCATIAEmbeddedComponentsPath);
               printTrace("EDAT_DB_Analyser : processAnalyingData : writting lstInvalidNames --->> : " + EDAT_AnalyserBusinessInterface.lstInvalidNames + " and strInvalidNamesPath ---> : " + this.strInvalidNamesPath + " and lstMissingFilesNames --->> :" + EDAT_AnalyserBusinessInterface.lstMissingFilesNames + " and strMissingFilesPath -->> :" + this.strMissingFilesPath);
            }

            if (this.isSelectiveMode) {
               this.AddCATRecordsAndSendJobs();
            }

            if ("ON".equals(objAnlayserConfig.getDashboard())) {
               this.writeAnalyserStatus_KO();
            }

            printTrace("EDAT_DB_Analyser :addKOStatusToXflowXML : Starts ");
            this.addKOStatusToXflowXML(EDAT_AnalyserBusinessInterface.lstInvalidNames);
            this.addKOStatusToXflowXML(EDAT_AnalyserBusinessInterface.lstMissingFilesNames);
            this.addKOStatusToXflowXML(EDAT_AnalyserBusinessInterface.lstHavingSpaceFilesNames);
            this.addKOStatusToXflowXML(EDAT_AnalyserBusinessInterface.lstFilenameLenGT100Char);
            this.addKOStatusToXflowXML(EDAT_AnalyserBusinessInterface.lstDescriptionLenGT256Char);
            this.addKOStatusToXflowXML(EDAT_AnalyserBusinessInterface.lstInvalidDescription);
            this.addKOStatusToXflowXML(EDAT_AnalyserBusinessInterface.lstComponentAssemblyNameMatches);
            this.addKOStatusToXflowXML(EDAT_AnalyserBusinessInterface.lstCATIAEmbeddedComponents);
            printTrace("EDAT_DB_Analyser :addKOStatusToXflowXML : Done ");
         } catch (IOException var13) {
            printTrace("EDAT_DB_Analyser : Error while getting Roots processAnalyingData ---> IOException:  " + var13.getMessage());
            System.out.println("EDAT_DB_Analyser :Error occurred while analysing roots : ----->>  " + var13.getMessage());
         } catch (Exception var14) {
            printTrace("EDAT_DB_Analyser : processAnalyingData ---> Exception:  " + var14.getMessage());
            System.out.println("EDAT_DB_Analyser :Error occurred while analysing roots : ----->>  " + var14.getMessage());
         }

         long endTime = System.currentTimeMillis();
         long startTime = xMLLogger.getStartDate();
         Date date = new Date(endTime - startTime);
         SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss:SSS");
         formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
         strEndtDate = formatter.format(date);
         String[] dur = strEndtDate.split(":");
         xMLLogger.AddNodewithTextValue("Duration", dur[0] + " hr " + dur[1] + " min " + dur[2] + " sec " + dur[3] + " msec ");
         xMLLogger.SaveXFlowXML();
         printTrace("EDAT_DB_Analyser : processAnalyingData ---> End of the method");
      }
   }

   private void postProcessingAnalyserData(Context context, String baseDir) throws Exception {
      printTrace("EDAT_DB_Analyser :  postProcessingAnalyserData ---> Start of the method ");

      try {
         String strRecoveryDataFisrtRev = "";
         String strRecoveryDataRestRev = "";
         List<String> firstRevList = null;
         List<String> restRevList = null;
         List<String> lines = null;
         String strRecoverymode = objAnlayserConfig.getRecoveryMode();
         this.rootList.clear();
         if ("ON".equalsIgnoreCase(strRecoverymode)) {
            strRecoveryDataFisrtRev = this.recoveryXML.getObjectID(this.strAnalysingType, "FirstRev");
            strRecoveryDataRestRev = this.recoveryXML.getObjectID(this.strAnalysingType, "RestRev");
         }

         String firstRevPath = objAnlayserConfig.getBaseDirectory() + "/" + this.strAnalysingType + "_FirstRev.txt";
         printTrace("EDAT_DB_Analyser :  postProcessingAnalyserData : firstRevPath--->" + firstRevPath);
         lines = this.readFileWithFallback(firstRevPath);
         printTrace("EDAT_DB_Analyser :  postProcessingAnalyserData : lines--->" + lines);
         lines = this.fixDecriptionWithNewLine(lines);
         Collections.sort(lines, new EDAT_Comparators(new Comparator[]{new EDAT_DateComparator(), new EDAT_IdComparator()}));
         if ("ON".equalsIgnoreCase(strRecoverymode)) {
            firstRevList = this.FindLastObjectImported(lines, strRecoveryDataFisrtRev);
         } else {
            firstRevList = lines;
         }

         printTrace("EDAT_DB_Analyser :  postProcessingAnalyserData : firstRevList--->" + firstRevList);
         this.extractIDForRoots(firstRevList);
         String restRevPath = objAnlayserConfig.getBaseDirectory() + "/" + this.strAnalysingType + "_RestRev.txt";
         printTrace("EDAT_DB_Analyser :  postProcessingAnalyserData : restRevPath--->" + restRevPath);
         lines = this.readFileWithFallback(restRevPath);
         printTrace("EDAT_DB_Analyser :  postProcessingAnalyserData : lines--->" + lines);
         lines = this.fixDecriptionWithNewLine(lines);
         Collections.sort(lines, new EDAT_Comparators(new Comparator[]{new EDAT_DateComparator(), new EDAT_IdComparator()}));
         if ("ON".equalsIgnoreCase(strRecoverymode)) {
            restRevList = this.FindLastObjectImported(lines, strRecoveryDataRestRev);
         } else {
            restRevList = lines;
         }

         printTrace("EDAT_DB_Analyser :  postProcessingAnalyserData : restRevList--->" + restRevList);
         this.extractIDForRoots(restRevList);
         printTrace("EDAT_DB_Analyser : postProcessingAnalyserData : firstRevList  : " + firstRevList + " and restRevList : " + restRevList);
         int iPath = 0;
         Object analyserList = new ArrayList();

         while(iPath < 2) {
            ((List)analyserList).clear();
            this.listTypeData.clear();
            this.fileCount = 0;
            if (iPath == 0) {
               printTrace("EDAT_DB_Analyser : postProcessingAnalyserData : strType  : " + this.strAnalysingType + " and firstRevPath : " + firstRevPath);
               this.typepath = firstRevPath;
               analyserList = firstRevList;
               this.strPath = "FirstRev";
               this.operation = "FirstRev";
            } else {
               printTrace("EDAT_DB_Analyser : postProcessingAnalyserData : strType  : " + this.strAnalysingType + " and restRevPath : " + restRevPath);
               this.typepath = restRevPath;
               analyserList = restRevList;
               this.strPath = "RestRev";
               this.operation = "RestRev";
            }

            if (!((List)analyserList).isEmpty() && ((List)analyserList).size() >= 1) {
               printTrace("postProcessingAnalyserData:  analyserList -->" + analyserList);
               this.analyser(context, (List)analyserList, baseDir);
            } else {
               System.out.println(" no data for type : " + this.strAnalysingType + " and " + this.strPath);
               printTrace("EDAT_DB_Analyser : analyser : no data for type : " + this.strAnalysingType + " and " + this.strPath);
               File f = new File(this.typepath);
               f.delete();
            }

            ++iPath;
            printTrace("EDAT_DB_Analyser : postProcessingAnalyserData ---> End of the method");
         }

      } catch (Exception var14) {
         printTrace("EDAT_DB_Analyser : postProcessingAnalyserData ---Exception in postProcessingAnalyserData : " + var14.getMessage());
         throw new Exception("EDAT_DB_Analyser : Error in while Processing Analyser Data : " + var14.getMessage());
      }
   }

   private void extractIDForRoots(List<String> finalList) {
      for(int i = 0; i < finalList.size(); ++i) {
         String line = (String)finalList.get(i);
         String[] arrInput = line.split("\\|");
         if (arrInput.length >= 6) {
            String strObjectId = UIUtil.isNotNullAndNotEmpty(arrInput[6]) ? arrInput[6].trim() : "";
            this.rootList.add(strObjectId);
         }
      }

      printTrace("EDAT_DB_Analyser : extractIDForRoots : rootList ----->>> " + this.rootList);
   }

   private List<String> fixDecriptionWithNewLine(List<String> finalList) {
      List<String> resultList = new ArrayList();
      String incompleteLine = "";
      int k = 0;

      for(int i = 0; i < finalList.size(); ++i) {
         String line = (String)finalList.get(i);
         String[] arrInput = line.split("\\|");
         if (arrInput.length == 12) {
            if (k > 0) {
               resultList.add(incompleteLine);
            }

            resultList.add(line);
            incompleteLine = "";
            k = 0;
         } else if (arrInput.length == 11) {
            if (k > 0) {
               resultList.add(incompleteLine);
            }

            incompleteLine = "";
            incompleteLine = line;
         } else {
            incompleteLine = incompleteLine + " " + line;
            ++k;
         }
      }

      if (k > 0) {
         resultList.add(incompleteLine);
      }

      printTrace("EDAT_DB_Analyser : fixDecriptionWithNewLine : resultList ----->>> " + resultList);
      return resultList;
   }

   private List<String> FindLastObjectImported(List<String> lines, String strRecoveryObjectId) {
      for(int i = 0; i < lines.size(); ++i) {
         String row = (String)lines.get(i);
         String[] arrInput = row.split("\\|");
         if (arrInput.length >= 6) {
            String id = UIUtil.isNotNullAndNotEmpty(arrInput[6]) ? arrInput[6].trim() : "";
            if (UIUtil.isNotNullAndNotEmpty(strRecoveryObjectId) && strRecoveryObjectId.equals(id)) {
               lines.subList(0, i + 1).clear();
               break;
            }
         }
      }

      printTrace("EDAT_DB_Analyser : FindLastObjectImported : lines ---->>> : " + lines);
      return lines;
   }

   private StringList readDocumentInputType() throws Exception {
      boolean bFlag = false;
      String path = objAnlayserConfig.getDecodedPropertiesPath() + File.separator + "config" + File.separator + "DocumentInputType.txt";
      List<String> lines = Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8);
      StringList lstTypes = new StringList();
      if (lines != null && lines.size() > 0) {
         String documentInputTypes = ((String)lines.get(0)).replaceAll("\\s*;\\s*", ";").trim();
         if (documentInputTypes.endsWith(";")) {
            documentInputTypes = documentInputTypes.substring(0, documentInputTypes.length() - 1);
         }

         if (UIUtil.isNotNullAndNotEmpty(documentInputTypes)) {
            lstTypes = StringUtil.split(documentInputTypes, ";");
            loggedXflow(xMLLogger, "OK", "Analysing Type", documentInputTypes);
         } else {
            bFlag = true;
         }
      } else {
         bFlag = true;
      }

      if (bFlag) {
         System.out.println("Enter type/s in DocumentInputType.txt");
         loggedXflowGlobalStatus(xMLLogger, "KO", "Enter type/s in DocumentInputType.txt");
         throw new Exception("DocumentInputType.txt is empty!");
      } else {
         return lstTypes;
      }
   }

   public static boolean checkLicense() {
      JDKFiveActivation key = new JDKFiveActivation();
      String targetId = new String();
      int remainingDays = 0;
      String errorMsg = new String();
      boolean isLicGranted = key.CheckAuthorization("EDT", targetId, remainingDays, errorMsg);
      return isLicGranted;
   }

   public void analyser(Context context, List<String> analyserList, String baseDir) {
      printTrace("EDAT_DB_Analyser : analyser ---> Start of the method");

      String type;
      try {
         int tempCount = 0;
         List<String> lines = analyserList;
         String row = "";
         String strCADType = objAnlayserConfig.getCADType();
         type = "";
         String name = "";
         String revision = "";
         String strModified = "";
         String fileName = "";
         String busId = "";
         String description = "";
         String strOriginated = "";
         String currentState = "";
         String project = "";
         String hasFile = "";
         String revindex = "";
         String[] arrInput = null;
         StringList busIds = new StringList();
         boolean fCleanDataCheck = true;
         MapList result = new MapList();
         Map mFillMap = new LinkedHashMap();
         boolean isNeedToImport = true;
         new HashMap();
         String busId_temp = "";
         EDAT_AnalyserBusinessInterface anlyserObj = new EDAT_AnalyserBusinessDAO();

         for(int iCount = 0; iCount < lines.size(); ++iCount) {
            row = (String)lines.get(iCount);
            printTrace("EDAT_DB_Analyser : analyser: row --->" + row);
            arrInput = row.split("\\|", -1);
            if (arrInput.length < 3) {
               System.out.println("Pass Proper arguments : TNR can not be null or empty at row " + iCount);
               printTrace("EDAT_DB_Analyser : analyser : Pass Proper arguments : TNR can not be null or empty at row " + iCount);
            } else {
               type = UIUtil.isNotNullAndNotEmpty(arrInput[0]) ? arrInput[0].trim() : type;
               name = UIUtil.isNotNullAndNotEmpty(arrInput[1]) ? arrInput[1].trim() : name;
               revision = UIUtil.isNotNullAndNotEmpty(arrInput[2]) ? arrInput[2].trim() : revision;
               strModified = UIUtil.isNotNullAndNotEmpty(arrInput[3]) ? arrInput[3].trim() : strModified;
               busId = UIUtil.isNotNullAndNotEmpty(arrInput[6]) ? arrInput[6].trim() : busId;
               description = UIUtil.isNotNullAndNotEmpty(arrInput[10]) ? arrInput[10].trim() : description;
               fileName = "";

               for(int i = 11; i < arrInput.length; ++i) {
                  fileName = fileName + (fileName.isEmpty() ? "" : "|") + arrInput[i].trim();
               }

               strOriginated = UIUtil.isNotNullAndNotEmpty(arrInput[5]) ? arrInput[5].trim() : strOriginated;
               currentState = UIUtil.isNotNullAndNotEmpty(arrInput[4]) ? arrInput[4].trim() : currentState;
               project = UIUtil.isNotNullAndNotEmpty(arrInput[7]) ? arrInput[7].trim() : project;
               hasFile = UIUtil.isNotNullAndNotEmpty(arrInput[8]) ? arrInput[8].trim() : hasFile;
               revindex = UIUtil.isNotNullAndNotEmpty(arrInput[9]) ? arrInput[9].trim() : revindex;
               printTrace("EDAT_DB_Analyser : analyser: the Type : " + type + " and Name :  " + name + " and Revision :  " + revision + "and " + "fileName : " + fileName + "  and busId : " + busId + " and description : " + description + " and project : " + project + " and hasFile : " + hasFile);
               System.out.println("\n-> Analysing data for TNR '" + type + "' '" + name + "' '" + revision + "'");
               fCleanDataCheck = anlyserObj.cleanDataCheck(type, name, revision, fileName, busId, description, baseDir, this.lstTypes);
               printTrace("EDAT_DB_Analyser : analyser: fCleanDataCheck --->" + fCleanDataCheck);
               description = "";
               if (fCleanDataCheck) {
                  isNeedToImport = true;
                  if (this.isUpdateMode) {
                     printTrace("EDAT_DB_Analyser : analyser: strModified --->" + strModified);
                     isNeedToImport = this.findUpdatedData(busId, isNeedToImport, strModified);
                  }

                  if (isNeedToImport && !this.mFinal.containsKey(busId)) {
                     busIds.add(busId);
                     printTrace("EDAT_DB_Analyser : analyser: busIds --->" + busIds);
                     if (type.equalsIgnoreCase("CATPart")) {
                        Map<String, String> resultMap = new HashMap();
                        resultMap.put("type", type);
                        resultMap.put("name", name);
                        resultMap.put("revision", revision);
                        resultMap.put("modified", strModified);
                        resultMap.put("format.file.name", fileName);
                        resultMap.put("id", busId);
                        resultMap.put("description", description);
                        resultMap.put("originated", strOriginated);
                        resultMap.put("current", currentState);
                        resultMap.put("project", project);
                        resultMap.put("format.hasfile", hasFile);
                        resultMap.put("revindex", revindex);
                        printTrace("EDAT_DB_Analyser : analyser (CATPart): resultMap --->" + resultMap);
                        result.add(resultMap);
                     }

                     ++tempCount;
                     if ((double)tempCount < this.threshold && iCount != lines.size() - 1) {
                        continue;
                     }
                  }

                  if ((double)tempCount == this.threshold || iCount == lines.size() - 1) {
                     printTrace("EDAT_DB_Analyser : analyser: strAnalysingType --->" + this.strAnalysingType + ", and busIds --> " + busIds);
                     if (!type.equalsIgnoreCase("CATPart")) {
                        result = anlyserObj.getRootObjectDetails(context, busIds, this.strAnalysingType, this.isSelectiveMode);
                     }

                     printTrace("EDAT_DB_Analyser : analyser: result --->" + result + ", and strCADType --> " + strCADType);
                     if ("NONCAD".equalsIgnoreCase(strCADType)) {
                        this.addNonCADDataInFile(result);
                     } else {
                        MapList mlResult = new MapList();
                        this.slProcessedList = new StringList();
                        StringList slChildProcessedList = new StringList();
                        new HashMap();
                        if (result != null && result.size() > 0) {
                           for(int i = 0; i < result.size(); ++i) {
                              Map<String, String> rootMap = (Map)result.get(i);
                              this.iAssemblyLevel = 0;
                              busId_temp = (String)rootMap.get("id");
                              rootMap.put("level", Integer.toString(this.iAssemblyLevel));
                              String strSkipObject;
                              if (this.isSelectiveMode && type.equalsIgnoreCase("CATDrawing")) {
                                 try {
                                    mlResult.add(rootMap);
                                    this.slProcessedList.add(busId_temp);
                                    mFillMap = this.analyzeCATDrawing(context, rootMap, mlResult, busId_temp, type, baseDir, (Map)mFillMap);
                                 } catch (Exception var37) {
                                    if (var37.getMessage().toString().contains("Cyclic")) {
                                       strSkipObject = type + ";" + name + ";" + revision + ";" + busId;
                                       writeToCyclicObjectFile(strSkipObject);
                                    } else {
                                       var37.printStackTrace();
                                    }
                                 }
                              } else if (objAnlayserConfig.getLstNonImmediateTypes().contains(this.strAnalysingType)) {
                                 try {
                                    mlResult.add(rootMap);
                                    this.slProcessedList.add(busId_temp);
                                    if (type.equalsIgnoreCase("SW Assembly Family")) {
                                       this.SWAssemblyCyclicDataCheck(rootMap, objAnlayserConfig.isGrtThan15x());
                                    }

                                    mlResult = this.analyzeNonImmediateTypes(context, rootMap, mlResult, "", this.iAssemblyLevel, slChildProcessedList, this.strAnalysingType, type);
                                    Map mUpdateMap = this.levelUpdate(mlResult, baseDir);
                                    ((Map)mFillMap).putAll(mUpdateMap);
                                 } catch (Exception var36) {
                                    if (var36.getMessage().toString().contains("Cyclic")) {
                                       strSkipObject = type + ";" + name + ";" + revision + ";" + busId;
                                       writeToCyclicObjectFile(strSkipObject);
                                    } else {
                                       var36.printStackTrace();
                                    }
                                 }
                              } else {
                                 ((Map)mFillMap).put(busId_temp, rootMap);
                              }
                           }
                        }

                        if (objAnlayserConfig.getLstImmediateTypes().contains(this.strAnalysingType)) {
                           this.splitLater = false;
                           printTrace("EDAT_DB_Analyser : analyser: mFillMap --->" + mFillMap);
                           if ("SOLIDWORKS".equalsIgnoreCase(strCADType)) {
                              printTrace("EDAT_DB_Analyser : analyser : Writing analysed data in Export.txt for " + strCADType);
                              this.AddSWRecordsInFile((Map)mFillMap);
                           } else if ("CATIA".equalsIgnoreCase(strCADType)) {
                              printTrace("EDAT_DB_Analyser : analyser : Writing analysed data in Export.txt for " + strCADType);
                              this.AddCATRecordsInFile((Map)mFillMap);
                           } else if ("INVENTOR".equalsIgnoreCase(strCADType) || "NX".equalsIgnoreCase(strCADType) || "CREO".equalsIgnoreCase(strCADType)) {
                              printTrace("EDAT_DB_Analyser : analyser : Writing analysed data in Export.txt for " + strCADType);
                              this.addDataInFile((Map)mFillMap);
                           }

                           result = new MapList();
                           mFillMap = new LinkedHashMap();
                        }
                     }
                  }

                  tempCount = 0;
                  busIds.clear();
               }
            }
         }

         if (objAnlayserConfig.getLstNonImmediateTypes().contains(this.strAnalysingType)) {
            this.splitLater = true;
            printTrace("EDAT_DB_Analyser : analyser ---> Code for Non Immediate types start");
            printTrace("EDAT_DB_Analyser : analyser : mFillMap ----->>> " + mFillMap);
            if ("SOLIDWORKS".equalsIgnoreCase(strCADType)) {
               printTrace("EDAT_DB_Analyser : analyser: Writing analysed data in Export.txt for " + strCADType);
               this.AddSWRecordsInFile((Map)mFillMap);
            } else if ("CATIA".equalsIgnoreCase(strCADType)) {
               printTrace("EDAT_DB_Analyser : analyser: Writing analysed data in Export.txt for " + strCADType);
               this.AddCATRecordsInFile((Map)mFillMap);
            } else if ("INVENTOR".equalsIgnoreCase(strCADType) || "NX".equalsIgnoreCase(strCADType) || "CREO".equalsIgnoreCase(strCADType)) {
               printTrace("EDAT_DB_Analyser : analyser: Writing analysed data in Export.txt for  " + strCADType);
               this.addDataInFile((Map)mFillMap);
            }

            printTrace("EDAT_DB_Analyser : analyser : mFillMap ----->>> " + mFillMap);
            new LinkedHashMap();
            this.sendJobsToActiveMQ(this.baseFolder);
            ++this.fileCount;
            printTrace("EDAT_DB_Analyser : analyser : fileCount ----->>> " + this.fileCount);
            printTrace("EDAT_DB_Analyser : analyser ---> Code for non-immediate types END");
         }
      } catch (Exception var38) {
         System.out.println("\n->ERROR MESSAGE : " + var38.getMessage());
         xMLLogger.UpdateGlobalStatus("KO");
         xMLLogger.AddGlobalStatusDetailInfo("DTK Analyser failed");
         xMLLogger.AddGlobalStatusDetailInfo(var38.getMessage());
         xMLLogger.SaveXFlowXML();
         printTrace("EDAT_DB_Analyser : analyser : DTK Analyser method failed ---> " + var38.getMessage());
      }

      long endTime = System.currentTimeMillis();
      DateFormat simple = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS Z");
      Date endDate = new Date(endTime);
      type = simple.format(endDate);
      xMLLogger.AddNodewithTextValue("EndDateTime", type);
      xMLLogger.SaveXFlowXML();
      printTrace("EDAT_DB_Analyser : analyser ----> End of the method");
   }

   private boolean SWAssemblyCyclicDataCheck(Map result, boolean isGtrt15x) throws Exception {
      if (result != null && result.size() > 0) {
         String AssemblyCyclicListExternal;
         String AssemblyCyclicList;
         if (!isGtrt15x) {
            AssemblyCyclicListExternal = (String)result.get("from[Active Version].to.from[Active Instance].to.from[CAD SubComponent].to.from[SW External Reference].to.id");
            AssemblyCyclicList = (String)result.get("from[Active Version].to.from[Active Instance].to.id");
         } else {
            AssemblyCyclicListExternal = (String)result.get("from[Active Instance].to.from[CAD SubComponent].to.from[SW External Reference].to.id");
            AssemblyCyclicList = (String)result.get("from[Active Instance].to.id");
         }

         StringList splitData = FrameworkUtil.split(AssemblyCyclicListExternal, ",");
         Iterator itr = splitData.iterator();

         while(itr.hasNext()) {
            String singlePathList = (String)itr.next();
            if (AssemblyCyclicList.contains(singlePathList)) {
               throw new Exception("Cyclic Data Found");
            }
         }
      }

      return true;
   }

   private void addDataInFile(Map mapFinal) {
      printTrace("EDAT_DB_Analyser : AddDataInFile ---> Start of the method");
      this.mlResults = new MapList();
      this.mlResults.addAll(mapFinal.values());
      printTrace("EDAT_DB_Analyser : AddDataInFile : mlResults --->" + this.mlResults);

      try {
         String outputFolder = objAnlayserConfig.getBaseDirectory();
         printTrace("EDAT_DB_Analyser : AddDataInFile : outputFolder --->>" + outputFolder);
         List<String> files = new ArrayList();
         new ArrayList();
         List<String> lstData = new ArrayList();
         Map<Integer, HashMap> mLevel = new HashMap();
         new HashMap();
         Map<String, List> mpCADData = new HashMap();
         String strTempType = this.strAnalysingType.replaceAll(" ", "");
         this.baseFolder = objAnlayserConfig.getBaseDirectory() + "\\" + strTempType + "\\" + this.strPath;
         printTrace("EDAT_DB_Analyser : AddDataInFile : strTempType -->> " + strTempType + " and baseFolder --->> " + this.baseFolder);
         String filePath = "";
         this.recoveryId = "";
         this.recoveryOriginatedDate = "";
         this.recoveryRev = "";
         String tempType = "";
         String tempName = "";
         String tempRev = "";
         String tempLevel = "";
         String tempCurrent = "";
         String strDuration = "";
         String strOriginated = "";
         String tempObjectId = "";

         for(int i = 0; i < this.mlResults.size(); ++i) {
            Map mapData = (Map)this.mlResults.get(i);
            printTrace("EDAT_DB_Analyser : AddDataInFile : mapData is ----->>>> " + mapData);
            tempType = (String)mapData.get("type");
            tempName = (String)mapData.get("name");
            tempRev = (String)mapData.get("revision");
            tempLevel = (String)mapData.get("level");
            tempCurrent = (String)mapData.get("current");
            strOriginated = (String)mapData.get("originated");
            tempObjectId = (String)mapData.get("id");
            new StringBuffer();
            if (!tempRev.contains(".")) {
               String tempFileFormat = this.getFileFormat(mapData, "|");
               String strType;
               if (this.rootList.contains(tempObjectId)) {
                  this.recoveryId = tempObjectId;
                  this.recoveryOriginatedDate = strOriginated;
                  this.recoveryRev = tempRev;
                  strType = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                  this.listTypeData.add(strType);
                  printTrace("EDAT_DB_Analyser : AddDataInFile : listTypeData ---->>> : " + this.listTypeData);
               }

               String output;
               if (!tempType.equals("INV Component") && !tempType.equals("INV Part Factory") && !tempType.equals("INV Drawing") && !tempType.equals("INV Presentation") && !tempType.equals("UG Model") && !tempType.equals("UG Drawing") && !tempType.equals("ProE Part") && !tempType.equals("ProE Drawing")) {
                  if (tempType.equals("INV Assembly") || tempType.equals("INV Assembly Factory") || tempType.equals("UG Assembly") || tempType.equals("ProE Assembly") || tempType.equals("ProE Assembly Family Table") || tempType.equals("ProE Part Family Table")) {
                     strType = tempType.replaceAll(" ", "");
                     this.baseFolder = objAnlayserConfig.getBaseDirectory() + "\\" + strType + "\\" + this.strPath;
                     outputFolder = this.baseFolder + "\\" + strType + "_" + tempLevel;
                     filePath = objAnlayserConfig.getBaseDirectory() + "\\" + strType + "\\" + this.strPath + "\\" + strType + "_" + tempLevel + "\\" + this.fileCount;
                     printTrace("EDAT_DB_Analyser : AddDataInFile : outputFolder --->> : " + outputFolder + "and filePath -->> :" + filePath + " and strType -->> :" + strType);
                     if (!files.contains(outputFolder)) {
                        files.add(outputFolder);
                     }

                     output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                     int mapLevel = Integer.parseInt(tempLevel);
                     printTrace("EDAT_DB_Analyser : AddDataInFile : output --->>> : " + output + " and mapLevel is :" + mapLevel);
                     ArrayList lines;
                     Object mCADObjects;
                     if (!mLevel.containsKey(mapLevel)) {
                        mCADObjects = new HashMap();
                        lines = new ArrayList();
                        lines.add(output);
                        ((Map)mCADObjects).put(strType, lines);
                     } else {
                        mCADObjects = (Map)mLevel.get(mapLevel);
                        if (!((Map)mCADObjects).containsKey(strType)) {
                           lines = new ArrayList();
                           lines.add(output);
                           ((Map)mCADObjects).put(strType, lines);
                        } else {
                           List<String> lines = (List)((Map)mCADObjects).get(strType);
                           lines.add(output);
                           ((Map)mCADObjects).put(strType, lines);
                        }
                     }

                     mLevel.put(mapLevel, (HashMap)mCADObjects);
                  }
               } else {
                  strType = tempType.replaceAll(" ", "");
                  printTrace("EDAT_DB_Analyser :  AddDataInFile : strType ---->>> " + strType);
                  filePath = objAnlayserConfig.getBaseDirectory() + "\\" + strType + "\\" + this.strPath + "\\" + strType + "_" + tempLevel + "\\" + this.fileCount;
                  output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                  printTrace("EDAT_DB_Analyser : AddDataInFile : output --->> : " + output + "and filePath -->> :" + filePath + " and strType -->> :" + strType);
                  if (!mpCADData.containsKey(strType)) {
                     lstData = new ArrayList();
                     ((List)lstData).add(output);
                  } else {
                     lstData = (List)mpCADData.get(strType);
                     ((List)lstData).add(output);
                  }

                  mpCADData.put(strType, lstData);
                  printTrace("EDAT_DB_Analyser : AddDataInFile : mpCADData ----->>>>> " + mpCADData);
               }

               long xFlowEndTime = (System.currentTimeMillis() - this.xFlowStartTime) / 1000L;
               long hours = xFlowEndTime / 3600L;
               long minutes = xFlowEndTime % 3600L / 60L;
               long seconds = xFlowEndTime % 60L;
               strDuration = String.format("%02dhr:%02dmin:%02dsec", hours, minutes, seconds);
               xMLLogger.AddObjectStatusNode(tempObjectId, tempType, "OK", strDuration);
               xMLLogger.AddObjectStatusDetailInfo(tempObjectId, "Analysis of Object " + tempName + " " + tempRev + " " + "OK");
            }
         }

         xMLLogger.SaveXFlowXML();
         if (this.splitLater) {
            printTrace("EDAT_DB_Analyser : AddDataInFile : mLevel ----->>>> : " + mLevel);
            this.writeAnalysedProdToFiles(files, mLevel);
         } else {
            printTrace("EDAT_DB_Analyser : AddDataInFile : lstData ----->>>> : " + lstData);
            this.writeToFileAndSendJob(filePath, (List)lstData);
         }

         printTrace("EDAT_DB_Analyser : AddDataInFile : Writing listTypeData -->> : " + this.listTypeData + " and typepath -->> : " + this.typepath);
         this.writeAnalysedFile(this.listTypeData, this.typepath);
      } catch (Exception var31) {
         xMLLogger.UpdateGlobalStatus("KO");
         xMLLogger.AddGlobalStatusDetailInfo("Error while adding records in file");
         xMLLogger.AddGlobalStatusDetailInfo(var31.getMessage());
         xMLLogger.SaveXFlowXML();
         System.out.println("ERROR : Error while adding records in file :: " + var31.getMessage());
         printTrace("EDAT_DB_Analyser : AddDataInFile : Error while adding records in file --> " + var31.getMessage());
      }

      printTrace("EDAT_DB_Analyser : AddDataInFile ---> End of the method");
   }

   private boolean findUpdatedData(String busid, boolean isNeedToImport, String strModified) {
      if (this.isUpdateMode) {
         String utcDate = this.getUTCDateTime(strModified);
         printTrace("EDAT_DB_Analyser : findUpdatedData: busid ---> " + busid);
         printTrace("EDAT_DB_Analyser : findUpdatedData: dbMap ---> " + this.dbMap);
         printTrace("EDAT_DB_Analyser : findUpdatedData: dbMap.containsKey(busid) ---> : " + this.dbMap.containsKey(busid));
         if (this.dbMap.containsKey(busid)) {
            List<String> tempList = (List)this.dbMap.get(busid);
            String date = (String)tempList.get(0);
            String status = (String)tempList.get(1);
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
            SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy h:mm:ss a", Locale.ENGLISH);
            printTrace("EDAT_DB_Analyser : findUpdatedData: the date : [ " + date + "] and status : [ " + status + "] ");
            printTrace("EDAT_DB_Analyser : findUpdatedData: df ---> " + df + " , and sdf --> " + sdf);

            try {
               printTrace("EDAT_DB_Analyser : findUpdatedData: date ---> " + date + " , and utcDate --> " + utcDate);
               Date date1 = df.parse(date);
               Date date2 = sdf.parse(utcDate);
               printTrace("EDAT_DB_Analyser : findUpdatedData: date1 ---> " + date1 + " , and date2 --> " + date2);
               if (date1.equals(date2) && status.equals("6")) {
                  isNeedToImport = false;
               } else {
                  isNeedToImport = true;
               }
            } catch (ParseException var12) {
               xMLLogger.UpdateGlobalStatus("KO");
               xMLLogger.AddGlobalStatusDetailInfo("Error in Date conversion");
               xMLLogger.AddGlobalStatusDetailInfo(var12.getMessage());
               xMLLogger.SaveXFlowXML();
               System.out.println("ERROR in finding the Updated date : -> " + var12.getMessage());
               printTrace("EDAT_DB_Analyser : findUpdatedData:  ERROR  in date conversion " + var12.getMessage());
            }
         }
      }

      printTrace("EDAT_DB_Analyser : findUpdatedData : isNeedToImport ---->>> " + isNeedToImport);
      return isNeedToImport;
   }

   private void AddSWRecordsInFile(Map mapFinal) {
      printTrace("EDAT_DB_Analyser : AddSWRecordsInFile ---> Start of the method");
      new EDAT_AnalyserBusinessDAO();
      this.mlResults = new MapList();
      this.mlResults.addAll(mapFinal.values());

      try {
         String outputFolder = objAnlayserConfig.getBaseDirectory();
         printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : outputFolder --->>" + outputFolder);
         List<String> files = new ArrayList();
         new ArrayList();
         List<String> lstSWData = new ArrayList();
         Map<Integer, HashMap> mLevel = new HashMap();
         new HashMap();
         Map<String, List> mpSWData = new HashMap();
         new HashMap();
         String strTempType = this.strAnalysingType.replaceAll(" ", "");
         this.baseFolder = objAnlayserConfig.getBaseDirectory() + "\\" + strTempType + "\\" + this.strPath;
         printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : strTempType -->> " + strTempType + " and baseFolder --->> " + this.baseFolder);
         String filePath = "";
         this.recoveryId = "";
         this.recoveryOriginatedDate = "";
         this.recoveryRev = "";
         String tempType = "";
         String tempName = "";
         String tempRev = "";
         String tempLevel = "";
         String tempCurrent = "";
         String strDuration = "";
         String strOriginated = "";
         String tempObjectId = "";

         for(int i = 0; i < this.mlResults.size(); ++i) {
            Map mpData = (Map)this.mlResults.get(i);
            printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : mpData is ----->>>> " + mpData);
            tempType = (String)mpData.get("type");
            tempName = (String)mpData.get("name");
            tempRev = (String)mpData.get("revision");
            tempLevel = (String)mpData.get("level");
            tempCurrent = (String)mpData.get("current");
            strOriginated = (String)mpData.get("originated");
            tempObjectId = (String)mpData.get("id");
            if (!tempRev.contains(".")) {
               String tempFileFormat = this.getFileFormat(mpData, "|");
               printTrace("EDAT_DB_Analyser :  AddSWRecordsInFile : rootList.contains(tempObjectId) --> : " + this.rootList.contains(tempObjectId));
               String strType;
               if (this.rootList.contains(tempObjectId)) {
                  this.recoveryId = tempObjectId;
                  this.recoveryOriginatedDate = strOriginated;
                  this.recoveryRev = tempRev;
                  strType = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                  this.listTypeData.add(strType);
                  printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : listTypeData ---->>> : " + this.listTypeData);
               }

               String output;
               if (!tempType.equals("SW Component Family") && !tempType.equals("SW Drawing")) {
                  printTrace("EDAT_DB_Analyser : AddSWRecordsInFile ---> Processing Assembly");
                  strType = tempType.replaceAll(" ", "");
                  this.baseFolder = objAnlayserConfig.getBaseDirectory() + "\\" + strType + "\\" + this.strPath;
                  outputFolder = this.baseFolder + "\\" + strType + "_" + tempLevel;
                  filePath = objAnlayserConfig.getBaseDirectory() + "\\" + strType + "\\" + this.strPath + "\\" + strType + "_" + tempLevel + "\\" + this.fileCount;
                  if (!files.contains(outputFolder)) {
                     files.add(outputFolder);
                  }

                  printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : outputFolder --->> : " + outputFolder + "and filePath -->> :" + filePath + " and strType -->> :" + strType);
                  output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                  int mapLevel = Integer.parseInt(tempLevel);
                  printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : output --->>> : " + output + " and mapLevel is :" + mapLevel);
                  ArrayList lines;
                  Object mCADObjects;
                  if (!mLevel.containsKey(mapLevel)) {
                     mCADObjects = new HashMap();
                     lines = new ArrayList();
                     lines.add(output);
                     ((Map)mCADObjects).put(strType, lines);
                  } else {
                     mCADObjects = (Map)mLevel.get(mapLevel);
                     if (!((Map)mCADObjects).containsKey(strType)) {
                        lines = new ArrayList();
                        lines.add(output);
                        ((Map)mCADObjects).put(strType, lines);
                     } else {
                        List<String> lines = (List)((Map)mCADObjects).get(strType);
                        lines.add(output);
                        ((Map)mCADObjects).put(strType, lines);
                     }
                  }

                  mLevel.put(mapLevel, (HashMap)mCADObjects);
                  printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : mLevel ----->>>> : " + mLevel + " and splitLater " + this.splitLater);
               } else {
                  if (tempType.equals("SW Component Family")) {
                     strType = "SWPart";
                  } else {
                     strType = tempType.replaceAll(" ", "");
                  }

                  filePath = objAnlayserConfig.getBaseDirectory() + "\\" + strType + "\\" + this.strPath + "\\" + strType + "_" + tempLevel + "\\" + this.fileCount;
                  output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                  printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : output --->> : " + output + "and filePath -->> :" + filePath + " and strType -->> :" + strType + " and mpSWData.containsKey(strType) --> :" + mpSWData.containsKey(strType));
                  if (!mpSWData.containsKey(strType)) {
                     lstSWData = new ArrayList();
                     ((List)lstSWData).add(output);
                  } else {
                     lstSWData = (List)mpSWData.get(strType);
                     ((List)lstSWData).add(output);
                  }

                  mpSWData.put(strType, lstSWData);
                  printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : mpSWData ----->>>>> : [ " + mpSWData + " ] ");
               }

               long xFlowEndTime = (System.currentTimeMillis() - this.xFlowStartTime) / 1000L;
               long hours = xFlowEndTime / 3600L;
               long minutes = xFlowEndTime % 3600L / 60L;
               long seconds = xFlowEndTime % 60L;
               strDuration = String.format("%02dhr:%02dmin:%02dsec", hours, minutes, seconds);
               xMLLogger.AddObjectStatusNode(tempObjectId, tempType, "OK", strDuration);
               xMLLogger.AddObjectStatusDetailInfo(tempObjectId, "Analysis of Object " + tempName + " " + tempRev + " " + "OK");
            }
         }

         xMLLogger.SaveXFlowXML();
         if (this.splitLater) {
            this.writeAnalysedProdToFiles(files, mLevel);
         } else {
            this.writeToFileAndSendJob(filePath, (List)lstSWData);
         }

         this.writeAnalysedFile(this.listTypeData, this.typepath);
         printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : writting strInvalidNamesPath -->> :" + this.strInvalidNamesPath + " and strMissingFilesPath --->> :" + this.strMissingFilesPath + " and strHavingSpaceNamePath -->> : " + this.strHavingSpaceNamePath + " and strHavingMoreThan100CharFileNamePath --> :" + this.strHavingMoreThan100CharFileNamePath + " and typepath -->> :" + this.typepath);
         printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : Writting listTypeData -->> : " + this.listTypeData + " and typepath -->> : " + this.typepath);
      } catch (Exception var31) {
         xMLLogger.UpdateGlobalStatus("KO");
         xMLLogger.AddGlobalStatusDetailInfo("Error while adding records in file");
         xMLLogger.AddGlobalStatusDetailInfo(var31.getMessage());
         xMLLogger.SaveXFlowXML();
         System.out.println("ERROR : Error while adding SW records in file :: " + var31.getMessage());
         printTrace("EDAT_DB_Analyser : AddSWRecordsInFile : Error while adding records in file --> " + var31.getMessage());
      }

      printTrace("EDAT_DB_Analyser : AddSWRecordsInFile ----> End of the method");
   }

   private void addLevelValue(MapList mlPartSubList, int level) {
      for(int i = 0; i < mlPartSubList.size(); ++i) {
         Map m = (Map)mlPartSubList.get(i);
         m.put("level", Integer.toString(level));
      }

   }

   public static StringList getObjectDetailList(Object object) {
      StringList valueStringList = new StringList();
      if (object == null) {
         return valueStringList;
      } else {
         if (object instanceof String) {
            String strValue = (String)object;
            byte[] bByte = new byte[]{7};
            String sep = new String(bByte);
            String[] strArrValue = strValue.split(sep, -1);
            List<String> valueList = Arrays.asList(strArrValue);
            valueStringList.addAll(valueList);
         } else if (object instanceof StringList) {
            valueStringList = (StringList)object;
         }

         return valueStringList;
      }
   }

   private void sendJobsToActiveMQ(String jmsReadDir) throws Exception {
      printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ ---> Start of the method");
      printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : jmsReadDir ----->>> " + jmsReadDir);
      System.out.println("\n->sendJobsToActiveMQ Sending JMS event : " + jmsReadDir);
      String finalPath = "";
      List<String> files = new ArrayList();
      String strCADType = objAnlayserConfig.getCADType();
      ArrayList CREOFiles;
      int i;
      File f;
      String name;
      List newFiles;
      int count;
      String tempPath;
      if ("NONCAD".equalsIgnoreCase(strCADType)) {
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ for CADTYPE --> NONCAD");
         CREOFiles = new ArrayList();
         this.getAllNonCADFiles(jmsReadDir, CREOFiles);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : nonCADFiles ----->>> " + CREOFiles);

         for(i = 0; i < CREOFiles.size(); ++i) {
            finalPath = (String)CREOFiles.get(i);
            f = new File(finalPath);
            name = f.getName();
            if (!name.equals("Analysis.txt") && !name.equals("Export.txt")) {
               printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : threshold ----->>> " + this.threshold);
               newFiles = this.splitFile(finalPath, this.threshold, false);

               for(count = 0; count < newFiles.size(); ++count) {
                  tempPath = (String)newFiles.get(count);
                  printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : tempPath ----->>> " + tempPath);
                  this.produce(tempPath, this.threshold);
               }

               this.recoveryXML.AddOperation(this.strAnalysingType, this.operation, this.recoveryId, this.recoveryRev, this.recoveryOriginatedDate);
               this.recoveryXML.SaveRecoveryXML();
            }
         }
      } else if (strCADType.equals("CATIA")) {
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ for CADTYPE --> CATIA");
         CREOFiles = new ArrayList();
         this.getAllCATPartFiles(jmsReadDir, CREOFiles);
         this.getAllFilesInFolder(jmsReadDir, files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : files ----->>>>: " + files);
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         this.getAllOtherCATObjectFiles(jmsReadDir, CREOFiles);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : CATPartfiles --->>>> " + CREOFiles);

         for(i = 0; i < CREOFiles.size(); ++i) {
            finalPath = (String)CREOFiles.get(i);
            f = new File(finalPath);
            name = f.getName();
            if (!name.equals("Analysis.txt") && !name.equals("Export.txt")) {
               printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : threshold --->>>> " + this.threshold);
               newFiles = this.splitFile(finalPath, this.threshold, false);

               for(count = 0; count < newFiles.size(); ++count) {
                  tempPath = (String)newFiles.get(count);
                  printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : tempPath --->>>> " + tempPath);
                  this.produce(tempPath, this.threshold);
               }

               this.recoveryXML.AddOperation(this.strAnalysingType, this.operation, this.recoveryId, this.recoveryRev, this.recoveryOriginatedDate);
               this.recoveryXML.SaveRecoveryXML();
            }
         }
      } else if (strCADType.equals("SOLIDWORKS")) {
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ for CADTYPE --> Solidworks");
         CREOFiles = new ArrayList();
         this.getAllSWAssemblyInFolder(jmsReadDir, files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : files ----->>>>: " + files);
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         files = new ArrayList();
         this.getAllSWDrawingFiles(jmsReadDir, files);
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : SWfiles --->>>> " + CREOFiles + " and SWfiles.size() -->> : " + CREOFiles.size());

         for(i = 0; i < CREOFiles.size(); ++i) {
            finalPath = (String)CREOFiles.get(i);
            f = new File(finalPath);
            name = f.getName();
            if (!name.equals("Analysis.txt") && !name.equals("Export.txt")) {
               printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : threshold --->>>> " + this.threshold);
               newFiles = this.splitFile(finalPath, this.threshold, false);

               for(count = 0; count < newFiles.size(); ++count) {
                  tempPath = (String)newFiles.get(count);
                  printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : tempPath --->>>> " + tempPath);
                  this.produce(tempPath, this.threshold);
               }

               this.recoveryXML.AddOperation(this.strAnalysingType, this.operation, this.recoveryId, this.recoveryRev, this.recoveryOriginatedDate);
               this.recoveryXML.SaveRecoveryXML();
            }
         }
      } else if ("INVENTOR".equalsIgnoreCase(strCADType)) {
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ for CADTYPE --> Inventor");
         CREOFiles = new ArrayList();
         this.getAllINVAssemblyInFolder(jmsReadDir, files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : files ----->>>>: " + files);
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         files = new ArrayList();
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : INVFiles --->>>> " + CREOFiles + " and INVFiles.size() -->> : " + CREOFiles.size());

         for(i = 0; i < CREOFiles.size(); ++i) {
            finalPath = (String)CREOFiles.get(i);
            f = new File(finalPath);
            name = f.getName();
            if (!name.equals("Analysis.txt") && !name.equals("Export.txt")) {
               printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : threshold --->>>> " + this.threshold);
               newFiles = this.splitFile(finalPath, this.threshold, false);

               for(count = 0; count < newFiles.size(); ++count) {
                  tempPath = (String)newFiles.get(count);
                  printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : tempPath --->>>> " + tempPath);
                  this.produce(tempPath, this.threshold);
               }

               this.recoveryXML.AddOperation(this.strAnalysingType, this.operation, this.recoveryId, this.recoveryRev, this.recoveryOriginatedDate);
               this.recoveryXML.SaveRecoveryXML();
            }
         }
      } else if (strCADType.equalsIgnoreCase("NX")) {
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ for CADTYPE --> NX");
         CREOFiles = new ArrayList();
         this.getAllNXAssemblyInFolder(jmsReadDir, files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : files ----->>>>: " + files);
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         files = new ArrayList();
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : NXFiles --->>>> " + CREOFiles + " and NXFiles.size() -->> : " + CREOFiles.size());

         for(i = 0; i < CREOFiles.size(); ++i) {
            finalPath = (String)CREOFiles.get(i);
            f = new File(finalPath);
            name = f.getName();
            if (!name.equals("Analysis.txt") && !name.equals("Export.txt")) {
               printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : threshold --->>>> " + this.threshold);
               newFiles = this.splitFile(finalPath, this.threshold, false);

               for(count = 0; count < newFiles.size(); ++count) {
                  tempPath = (String)newFiles.get(count);
                  printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : tempPath --->>>> " + tempPath);
                  this.produce(tempPath, this.threshold);
               }

               this.recoveryXML.AddOperation(this.strAnalysingType, this.operation, this.recoveryId, this.recoveryRev, this.recoveryOriginatedDate);
               this.recoveryXML.SaveRecoveryXML();
            }
         }
      } else if (strCADType.equalsIgnoreCase("CREO")) {
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ for CADTYPE --> CREO");
         CREOFiles = new ArrayList();
         this.getAllCREOAssemblyInFolder(jmsReadDir, files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : files ----->>>>: " + files);
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         files = new ArrayList();
         Collections.sort(files, new EDAT_NameComparator());
         CREOFiles.addAll(files);
         printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : CREOFiles --->>>> " + CREOFiles + " and CREOFiles.size() -->> : " + CREOFiles.size());

         for(i = 0; i < CREOFiles.size(); ++i) {
            finalPath = (String)CREOFiles.get(i);
            f = new File(finalPath);
            name = f.getName();
            if (!name.equals("Analysis.txt") && !name.equals("Export.txt")) {
               printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : threshold --->>>> " + this.threshold);
               newFiles = this.splitFile(finalPath, this.threshold, false);

               for(count = 0; count < newFiles.size(); ++count) {
                  tempPath = (String)newFiles.get(count);
                  printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ : tempPath --->>>> " + tempPath);
                  this.produce(tempPath, this.threshold);
               }

               this.recoveryXML.AddOperation(this.strAnalysingType, this.operation, this.recoveryId, this.recoveryRev, this.recoveryOriginatedDate);
               this.recoveryXML.SaveRecoveryXML();
            }
         }
      }

      System.out.println("-> JMS Event sent\n");
      printTrace("EDAT_DB_Analyser : sendJobsToActiveMQ ---> End of the method");
   }

   private void getAllSWDrawingFiles(String jmsReadDir, List<String> otherCATObjectfiles) {
      File folder = new File(jmsReadDir);

      try {
         if (folder.isDirectory()) {
            File[] var7;
            int var6 = (var7 = folder.listFiles()).length;

            for(int var5 = 0; var5 < var6; ++var5) {
               File f = var7[var5];
               if (f.isFile() && f.getName().contains("SWDrawing")) {
                  otherCATObjectfiles.add(f.getCanonicalPath());
               } else if (f.isDirectory()) {
                  this.getAllSWDrawingFiles(f.getCanonicalPath(), otherCATObjectfiles);
               }
            }
         }
      } catch (IOException var8) {
         printTrace("EDAT_DB_Analyser : getAllSWDrawingFiles : IOException while getting SW Drawing Files ----> " + var8.getMessage());
         System.out.println("EDAT_DB_Analyser : IOException while getting SW Drawing Files ----> " + var8.getMessage());
      } catch (Exception var9) {
         printTrace("EDAT_DB_Analyser : getAllSWDrawingFiles : Exception while getting SW Drawing Files ----> " + var9.getMessage());
         System.out.println("EDAT_DB_Analyser : Exception while getting SW Drawing Files ----> " + var9.getMessage());
      }

   }

   private void getAllOtherCATObjectFiles(String jmsReadDir, List<String> otherCATObjectfiles) {
      File folder = new File(jmsReadDir);

      try {
         if (folder.isDirectory()) {
            File[] var7;
            int var6 = (var7 = folder.listFiles()).length;

            for(int var5 = 0; var5 < var6; ++var5) {
               File f = var7[var5];
               if (f.isFile() && (f.getName().contains("CATAnalysis") || f.getName().contains("CATProcess") || f.getName().contains("CATAnalysis") || f.getName().contains("CATIA Catalog") || f.getName().contains("CATShape") || f.getName().contains("CATIA V4 Model") || f.getName().contains("CATIA CGR"))) {
                  otherCATObjectfiles.add(f.getCanonicalPath());
               } else if (f.isDirectory()) {
                  this.getAllOtherCATObjectFiles(f.getCanonicalPath(), otherCATObjectfiles);
               }
            }
         }
      } catch (IOException var8) {
         printTrace("EDAT_DB_Analyser : getAllOtherCATObjectFiles : IOException is ----> " + var8.getMessage());
         System.out.println("EDAT_DB_Analyser : IOException while getting all the other CAT Object files :  ----> " + var8.getMessage());
      } catch (Exception var9) {
         printTrace("EDAT_DB_Analyser : getAllOtherCATObjectFiles : Exception is ----> " + var9.getMessage());
         System.out.println("EDAT_DB_Analyser : IOException while getting all the other CAT Object files : ----> " + var9.getMessage());
      }

   }

   private void getAllCATAnalysisFiles(String jmsReadDir, List<String> otherCATObjectfiles) {
      File folder = new File(jmsReadDir);

      try {
         if (folder.isDirectory()) {
            File[] var7;
            int var6 = (var7 = folder.listFiles()).length;

            for(int var5 = 0; var5 < var6; ++var5) {
               File f = var7[var5];
               if (f.isFile() && f.getName().contains("CATAnalysis")) {
                  otherCATObjectfiles.add(f.getCanonicalPath());
               } else if (f.isDirectory()) {
                  this.getAllCATAnalysisFiles(f.getCanonicalPath(), otherCATObjectfiles);
               }
            }
         }
      } catch (IOException var8) {
         printTrace("EDAT_DB_Analyser : getAllCATAnalysisFiles : IOException is ----> " + var8.getMessage());
         System.out.println("EDAT_DB_Analyser :IOException while getting the CATAnalysis Files : ----> " + var8.getMessage());
      } catch (Exception var9) {
         printTrace("EDAT_DB_Analyser : getAllCATAnalysisFiles : Exception is ----> " + var9.getMessage());
         System.out.println("EDAT_DB_Analyser :Exception while getting the CATAnalysis Files : ----> " + var9.getMessage());
      }

   }

   private void getAllCATPartFiles(String jmsReadDir, List<String> CATPartfiles) throws Exception {
      File folder = new File(jmsReadDir);

      try {
         if (folder.isDirectory()) {
            File[] var7;
            int var6 = (var7 = folder.listFiles()).length;

            for(int var5 = 0; var5 < var6; ++var5) {
               File f = var7[var5];
               if (f.isFile() && f.getName().contains("CATPart")) {
                  CATPartfiles.add(f.getCanonicalPath());
               } else if (f.isDirectory()) {
                  this.getAllCATPartFiles(f.getCanonicalPath(), CATPartfiles);
               }
            }
         }
      } catch (IOException var8) {
         printTrace("EDAT_DB_Analyser : getAllCATPartFiles : IOException is ----> " + var8.getMessage());
         System.out.println("EDAT_DB_Analyser :IOException while getting all CATPart Files is ----> " + var8.getMessage());
      } catch (Exception var9) {
         printTrace("EDAT_DB_Analyser : getAllCATPartFiles : Exception is ----> " + var9.getMessage());
         System.out.println("EDAT_DB_Analyser : Exception while getting all CATPart Files is ----> " + var9.getMessage());
      }

   }

   private void getAllNonCADFiles(String jmsReadDir, List<String> nonCADFiles) throws Exception {
      File folder = new File(jmsReadDir);

      try {
         if (folder.isDirectory()) {
            File[] var7;
            int var6 = (var7 = folder.listFiles()).length;

            for(int var5 = 0; var5 < var6; ++var5) {
               File f = var7[var5];
               if (f.isFile()) {
                  nonCADFiles.add(f.getCanonicalPath());
               } else if (f.isDirectory()) {
                  this.getAllNonCADFiles(f.getCanonicalPath(), nonCADFiles);
               }
            }
         }
      } catch (IOException var8) {
         printTrace("EDAT_DB_Analyser : getAllNonCADFiles : IOException is ----> " + var8.getMessage());
         System.out.println("EDAT_DB_Analyser : Exception while getting AllNonCADFiles ----> " + var8.getMessage());
      } catch (Exception var9) {
         printTrace("EDAT_DB_Analyser : getAllNonCADFiles : Exception is ----> " + var9.getMessage());
         System.out.println("EDAT_DB_Analyser :  Exception while getting AllNonCADFiles ----> " + var9.getMessage());
      }

   }

   private void getAllSWPartFiles(String jmsReadDir, List<String> SWPartfiles) throws Exception {
      File folder = new File(jmsReadDir);

      try {
         if (folder.isDirectory()) {
            File[] var7;
            int var6 = (var7 = folder.listFiles()).length;

            for(int var5 = 0; var5 < var6; ++var5) {
               File f = var7[var5];
               if (f.isFile() && f.getName().contains("SWPart")) {
                  SWPartfiles.add(f.getCanonicalPath());
               } else if (f.isDirectory()) {
                  this.getAllSWPartFiles(f.getCanonicalPath(), SWPartfiles);
               }
            }
         }
      } catch (IOException var8) {
         printTrace("EDAT_DB_Analyser : getAllSWPartFiles : IOException is ----> " + var8.getMessage());
         System.out.println("EDAT_DB_Analyser :IOException while getting SWPart Files : ----> " + var8.getMessage());
      } catch (Exception var9) {
         printTrace("EDAT_DB_Analyser : getAllSWPartFiles : Exception is ----> " + var9.getMessage());
         System.out.println("EDAT_DB_Analyser : IOException while getting SWPart Files :  ----> " + var9.getMessage());
      }

   }

   private List<String> getAllFilesInFolder(String jmsReadDir, List<String> files) throws Exception, IOException {
      File folder = new File(jmsReadDir);
      if (folder.isDirectory()) {
         File[] var7;
         int var6 = (var7 = folder.listFiles()).length;

         for(int var5 = 0; var5 < var6; ++var5) {
            File f = var7[var5];
            if (f.isFile() && !f.getName().contains("CATPart") && !f.getName().contains("CATProcess") && !f.getName().contains("CATIA Catalog") && !f.getName().contains("CATShape") && !f.getName().contains("CATAnalysis") && !f.getName().contains("CATIA V4 Model") && !f.getName().contains("CATIA CGR") && !f.getName().contains("MissingFileNames")) {
               files.add(f.getCanonicalPath());
            } else if (f.isDirectory()) {
               this.getAllFilesInFolder(f.getCanonicalPath(), files);
            }
         }
      }

      return files;
   }

   private List<String> getAllSWAssemblyInFolder(String jmsReadDir, List<String> files) throws Exception, IOException {
      File folder = new File(jmsReadDir);
      if (folder.isDirectory()) {
         File[] var7;
         int var6 = (var7 = folder.listFiles()).length;

         for(int var5 = 0; var5 < var6; ++var5) {
            File f = var7[var5];
            if (f.isFile() && f.getName().contains("SWAssemblyFamily")) {
               files.add(f.getCanonicalPath());
            } else if (f.isDirectory()) {
               this.getAllSWAssemblyInFolder(f.getCanonicalPath(), files);
            }
         }
      }

      return files;
   }

   private List<String> getAllINVAssemblyInFolder(String jmsReadDir, List<String> files) throws Exception, IOException {
      File folder = new File(jmsReadDir);
      if (folder.isDirectory()) {
         File[] var7;
         int var6 = (var7 = folder.listFiles()).length;

         for(int var5 = 0; var5 < var6; ++var5) {
            File f = var7[var5];
            if (f.isFile() && f.getName().contains("INVAssembly")) {
               files.add(f.getCanonicalPath());
            } else if (f.isDirectory()) {
               this.getAllINVAssemblyInFolder(f.getCanonicalPath(), files);
            }
         }
      }

      return files;
   }

   private List<String> getAllNXAssemblyInFolder(String jmsReadDir, List<String> files) throws Exception, IOException {
      File folder = new File(jmsReadDir);
      if (folder.isDirectory()) {
         File[] var7;
         int var6 = (var7 = folder.listFiles()).length;

         for(int var5 = 0; var5 < var6; ++var5) {
            File f = var7[var5];
            if (f.isFile() && f.getName().contains("UGAssembly")) {
               files.add(f.getCanonicalPath());
            } else if (f.isDirectory()) {
               this.getAllNXAssemblyInFolder(f.getCanonicalPath(), files);
            }
         }
      }

      return files;
   }

   private List<String> getAllCREOAssemblyInFolder(String jmsReadDir, List<String> files) throws Exception, IOException {
      File folder = new File(jmsReadDir);
      if (folder.isDirectory()) {
         File[] var7;
         int var6 = (var7 = folder.listFiles()).length;

         for(int var5 = 0; var5 < var6; ++var5) {
            File f = var7[var5];
            if (!f.isFile() || !f.getName().contains("ProEAssembly") && !f.getName().contains("ProEPart")) {
               if (f.isDirectory()) {
                  this.getAllCREOAssemblyInFolder(f.getCanonicalPath(), files);
               }
            } else {
               files.add(f.getCanonicalPath());
            }
         }
      }

      return files;
   }

   public void produce(String analysisFilePath, double threshold) throws JMSException, Exception {
      printTrace("EDAT_DB_Analyser : produce ---> Start of the method");
      ConnectionFactory factory = new ActiveMQConnectionFactory(this.getParamaterValueFromXML(this.doc, "ActiveMQPath"));
      Connection connection = null;
      Session session = null;
      String level = "";
      String messageText = "";

      try {
         connection = factory.createConnection();
         session = connection.createSession(true, 0);
         Destination destination = session.createQueue(this.getParamaterValueFromXML(this.doc, "ExportQueueName"));
         MessageProducer producer = session.createProducer(destination);
         producer.setDeliveryMode(2);
         TextMessage message = session.createTextMessage();
         String type = analysisFilePath.split("\\\\")[5].replaceAll("\\s+", "");
         printTrace("EDAT_DB_Analyser : produce : type ----->>> " + type + "and destination ----->> " + destination);
         String sText;
         if (!analysisFilePath.contains("\\CATPart\\") && !analysisFilePath.contains("\\SWParts\\")) {
            if (analysisFilePath.contains("\\" + type + "_")) {
               String[] temp = analysisFilePath.split("\\\\" + type + "_");
               level = temp[1].split("\\\\")[0];
               sText = analysisFilePath.substring(0, analysisFilePath.lastIndexOf("\\"));
               printTrace("EDAT_DB_Analyser : produce : path ----->>> " + sText);
            }
         } else {
            level = "-1";
            String path = analysisFilePath.substring(0, analysisFilePath.lastIndexOf("\\"));
            printTrace("EDAT_DB_Analyser : produce : path ----->>> " + path);
         }

         printTrace("EDAT_DB_Analyser : produce : level ----->>> " + level);
         if (UIUtil.isNotNullAndNotEmpty(level)) {
            message.setStringProperty("level", level);
            message.setStringProperty("type", type);
            messageText = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Message><Operation>Export</Operation><ANALYSIS_FILE_PATH>" + analysisFilePath + "</ANALYSIS_FILE_PATH>" + "</Message>";
         } else {
            message.setStringProperty("level", "0");
            message.setStringProperty("type", type);
            messageText = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Message><Operation>Export</Operation><ANALYSIS_FILE_PATH>" + analysisFilePath + "</ANALYSIS_FILE_PATH>" + "</Message>";
         }

         printTrace("EDAT_DB_Analyser : produce : messageText ----->>> " + messageText);
         this.flag = this.getParamaterValueFromXML(this.doc, "Dashboard");
         printTrace("EDAT_DB_Analyser : produce : flag ----->>> " + this.flag);
         if (UIUtil.isNullOrEmpty(this.flag)) {
            this.flag = "OFF";
         }

         if ("ON".equals(this.flag)) {
            this.writeAnalyserStatus_OK(this.mlResults);
            this.mlResults = new MapList();
         }

         byte[] b = messageText.getBytes(StandardCharsets.UTF_8);
         sText = new String(b, StandardCharsets.UTF_8);
         message.setText(sText);
         producer.send(message);
         session.commit();
         message.getJMSMessageID();
      } finally {
         closeSilently(connection, session);
      }

      printTrace("EDAT_DB_Analyser : produce ---> End of the method");
   }

   private static void closeSilently(Connection connection, Session session) throws JMSException {
      if (session != null) {
         session.close();
      }

      if (connection != null) {
         connection.close();
      }

   }

   public void validateDirectory(String directory) throws IOException {
      File opDir = null;
      if (this.isForceCreateDir) {
         opDir = EDAT_AnalyserUtils.createDirectory(directory);
      } else {
         opDir = new File(directory);
         if (!EDAT_AnalyserUtils.isDirectoryExist(opDir)) {
            throw new IOException("Directory: " + directory + " does not exist.");
         }
      }

   }

   private void AddCATRecordsInFile(Map mapFinal) {
      printTrace("EDAT_DB_Analyser : AddCATRecordsInFile ----> Start of the method");
      new EDAT_AnalyserBusinessDAO();
      this.mlResults = new MapList();
      this.mlResults.addAll(mapFinal.values());
      this.mlResults.addSortKey("originated", "ascending", "date");
      this.mlResults.sort();

      try {
         String outputFolder = objAnlayserConfig.getBaseDirectory();
         printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : outputFolder --->>" + outputFolder);
         List<String> files = new ArrayList();
         new ArrayList();
         List<String> CATObjects = new ArrayList();
         new ArrayList();
         Map<Integer, HashMap> mLevel = new HashMap();
         new HashMap();
         Map<String, List> mCATPart = new HashMap();
         Map<String, List> mOtherCATObjects = new HashMap();
         String filePath = "";
         String tempType = "";
         String tempName = "";
         String tempRev = "";
         String tempLevel = "";
         String tempCurrent = "";
         String strDuration = "";
         String strOriginated = "";
         String tempObjectId = "";
         String tempRevIndex = "";

         for(int i = 0; i < this.mlResults.size(); ++i) {
            Map mpData = (Map)this.mlResults.get(i);
            printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : mpData is ----->>>> " + mpData);
            tempType = (String)mpData.get("type");
            tempName = (String)mpData.get("name");
            tempRev = (String)mpData.get("revision");
            tempLevel = (String)mpData.get("level");
            tempCurrent = (String)mpData.get("current");
            strDuration = String.valueOf(mpData.get("Duration"));
            strOriginated = (String)mpData.get("originated");
            tempObjectId = (String)mpData.get("id");
            tempRevIndex = (String)mpData.get("revindex");
            if (!tempRev.contains(".")) {
               String tempFileFormat = this.getFileFormat(mpData, "|");
               String output;
               if (this.rootList.contains(tempObjectId)) {
                  this.recoveryId = tempObjectId;
                  this.recoveryOriginatedDate = strOriginated;
                  this.recoveryRev = tempRev;
                  output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                  this.listTypeData.add(output);
                  printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : listTypeData ---->>> : " + this.listTypeData);
               }

               if (!tempType.equals("CATProcess") && !tempType.equals("CATIA Catalog") && !tempType.equals("CATShape") && !tempType.equals("CATAnalysis") && !tempType.equals("CATIA V4 Model") && !tempType.equals("CATIA CGR") && !tempType.equals("CATAnalysisComputations") && !tempType.equals("CATAnalysisResults")) {
                  if (tempType.equals("CATPart")) {
                     filePath = objAnlayserConfig.getBaseDirectory() + "\\" + tempType + "\\" + this.strPath + "\\" + tempType + "_" + tempLevel + "\\" + this.fileCount;
                     output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                     if (this.isSelectiveMode) {
                        this.allCATPartsBusId.add(tempObjectId);
                        if ("0".equals(tempRevIndex)) {
                           if (!this.sCATPart.containsKey("First_Rev_CATParts")) {
                              this.firstRevParts = new ArrayList();
                              this.firstRevParts.add(output);
                           } else {
                              this.firstRevParts = (List)this.sCATPart.get("First_Rev_CATParts");
                              this.firstRevParts.add(output);
                           }
                        } else if (!this.sCATPart.containsKey("Rest_Rev_CATParts")) {
                           this.restRevParts = new ArrayList();
                           this.restRevParts.add(output);
                        } else {
                           this.restRevParts = (List)this.sCATPart.get("Rest_Rev_CATParts");
                           this.restRevParts.add(output);
                        }

                        this.sCATPart.put("First_Rev_CATParts", this.firstRevParts);
                        this.sCATPart.put("Rest_Rev_CATParts", this.restRevParts);
                        printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : sCATPart ----->>>>> : " + this.sCATPart);
                     } else {
                        if (!mCATPart.containsKey("CATPart")) {
                           CATObjects = new ArrayList();
                           ((List)CATObjects).add(output);
                        } else {
                           CATObjects = (List)mCATPart.get("CATPart");
                           ((List)CATObjects).add(output);
                        }

                        mCATPart.put("CATPart", CATObjects);
                        printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : mCATPart ----->>>>> : " + mCATPart);
                     }
                  } else {
                     this.baseFolder = objAnlayserConfig.getBaseDirectory() + "\\" + tempType + "\\" + this.strPath;
                     outputFolder = this.baseFolder + "\\" + tempType + "_" + tempLevel;
                     filePath = objAnlayserConfig.getBaseDirectory() + "\\" + tempType + "\\" + "\\" + this.strPath + "\\" + tempType + "_" + tempLevel + "\\" + this.fileCount;
                     if (!files.contains(outputFolder)) {
                        files.add(outputFolder);
                     }

                     output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                     int mapLevel = Integer.parseInt(tempLevel);
                     printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : outputFolder --->> : " + outputFolder + "and filePath -->> :" + filePath + " and mapLevel -->> :" + mapLevel + " and output --> :" + output);
                     ArrayList lines;
                     Object mCADObjects;
                     List lines;
                     if (this.isSelectiveMode && tempType.equals("CATProduct")) {
                        this.allCATProductsBusId.add(tempObjectId);
                        if ("FirstRev".equals(this.strPath)) {
                           printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : !firstRevLevel.containsKey(mapLevel)-----" + !this.firstRevLevel.containsKey(mapLevel));
                           if (!this.firstRevLevel.containsKey(mapLevel)) {
                              mCADObjects = new HashMap();
                              lines = new ArrayList();
                              lines.add(output);
                              this.firstRevProducts.add(output);
                              ((Map)mCADObjects).put(tempType, lines);
                           } else {
                              mCADObjects = (Map)this.firstRevLevel.get(mapLevel);
                              if (!((Map)mCADObjects).containsKey(tempType)) {
                                 lines = new ArrayList();
                                 lines.add(output);
                                 this.firstRevProducts.add(output);
                                 ((Map)mCADObjects).put(tempType, lines);
                              } else {
                                 lines = (List)((Map)mCADObjects).get(tempType);
                                 lines.add(output);
                                 this.firstRevProducts.add(output);
                                 ((Map)mCADObjects).put(tempType, lines);
                              }
                           }

                           this.firstRevLevel.put(mapLevel, (HashMap)mCADObjects);
                           printTrace("EDAT_DB_Analyser :  AddCATRecordsInFile : firstRevLevel---> [ " + this.firstRevLevel + " ]");
                        } else {
                           printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : !restRevLevel.containsKey(mapLevel)-----" + !this.restRevLevel.containsKey(mapLevel));
                           if (!this.restRevLevel.containsKey(mapLevel)) {
                              mCADObjects = new HashMap();
                              lines = new ArrayList();
                              lines.add(output);
                              this.restRevProducts.add(output);
                              ((Map)mCADObjects).put(tempType, lines);
                           } else {
                              mCADObjects = (Map)this.restRevLevel.get(mapLevel);
                              if (!((Map)mCADObjects).containsKey(tempType)) {
                                 lines = new ArrayList();
                                 lines.add(output);
                                 this.restRevProducts.add(output);
                                 ((Map)mCADObjects).put(tempType, lines);
                              } else {
                                 lines = (List)((Map)mCADObjects).get(tempType);
                                 lines.add(output);
                                 this.restRevProducts.add(output);
                                 ((Map)mCADObjects).put(tempType, lines);
                              }
                           }

                           this.restRevLevel.put(mapLevel, (HashMap)mCADObjects);
                           printTrace("EDAT_DB_Analyser :  AddCATRecordsInFile : restRevLevel---> [ " + this.restRevLevel + " ]");
                        }
                     } else if (this.isSelectiveMode && tempType.equals("CATDrawing")) {
                        this.AnalyzeCATDrawings.add(output);
                        if ("0".equals(tempRevIndex)) {
                           if (!this.sCATDrawing.containsKey("First_Rev_CATDrawings")) {
                              this.firstRevDrawing = new ArrayList();
                              this.firstRevDrawing.add(output);
                           } else {
                              this.firstRevDrawing = (List)this.sCATDrawing.get("First_Rev_CATDrawings");
                              this.firstRevDrawing.add(output);
                           }
                        } else if (!this.sCATDrawing.containsKey("Rest_Rev_CATDrawings")) {
                           this.restRevDrawing = new ArrayList();
                           this.restRevDrawing.add(output);
                        } else {
                           this.restRevDrawing = (List)this.sCATDrawing.get("Rest_Rev_CATDrawings");
                           this.restRevDrawing.add(output);
                        }

                        this.sCATDrawing.put("First_Rev_CATDrawings", this.firstRevDrawing);
                        this.sCATDrawing.put("Rest_Rev_CATDrawings", this.restRevDrawing);
                        printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : sCATDrawing ----->>>>> : " + this.sCATDrawing);
                     } else {
                        printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : !mLevel.containsKey(mapLevel)-----" + !mLevel.containsKey(mapLevel));
                        if (!mLevel.containsKey(mapLevel)) {
                           mCADObjects = new HashMap();
                           lines = new ArrayList();
                           lines.add(output);
                           ((List)CATObjects).add(output);
                           ((Map)mCADObjects).put(tempType, lines);
                        } else {
                           mCADObjects = (Map)mLevel.get(mapLevel);
                           if (!((Map)mCADObjects).containsKey(tempType)) {
                              lines = new ArrayList();
                              lines.add(output);
                              ((List)CATObjects).add(output);
                              ((Map)mCADObjects).put(tempType, lines);
                           } else {
                              lines = (List)((Map)mCADObjects).get(tempType);
                              lines.add(output);
                              ((List)CATObjects).add(output);
                              ((Map)mCADObjects).put(tempType, lines);
                           }
                        }

                        mLevel.put(mapLevel, (HashMap)mCADObjects);
                     }
                  }
               } else {
                  filePath = objAnlayserConfig.getBaseDirectory() + "\\" + tempType + "\\" + this.strPath + "\\" + tempType + "_" + tempLevel + "\\" + this.fileCount;
                  output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
                  printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : output --->> : " + output + "and filePath -->> :" + filePath + " and mOtherCATObjects.containsKey(tempType) --> :" + mOtherCATObjects.containsKey(tempType));
                  Object otherCATObjects;
                  if (!mOtherCATObjects.containsKey(tempType)) {
                     otherCATObjects = new ArrayList();
                     ((List)otherCATObjects).add(output);
                     ((List)CATObjects).add(output);
                  } else {
                     otherCATObjects = (List)mOtherCATObjects.get(tempType);
                     ((List)otherCATObjects).add(output);
                     ((List)CATObjects).add(output);
                  }

                  mOtherCATObjects.put(tempType, otherCATObjects);
               }

               long xFlowEndTime = (System.currentTimeMillis() - this.xFlowStartTime) / 1000L;
               long hours = xFlowEndTime / 3600L;
               long minutes = xFlowEndTime % 3600L / 60L;
               long seconds = xFlowEndTime % 60L;
               strDuration = String.format("%02dhr:%02dmin:%02dsec", hours, minutes, seconds);
               xMLLogger.AddObjectStatusNode(tempObjectId, tempType, "OK", strDuration);
               xMLLogger.AddObjectStatusDetailInfo(tempObjectId, "Analysis of Object " + tempName + " " + tempRev + " " + "OK");
               xMLLogger.SaveXFlowXML();
            }
         }

         if (!this.isSelectiveMode) {
            if (this.splitLater) {
               printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : mLevel ----->>>> : [ " + mLevel + " ]");
               this.writeAnalysedProdToFiles(files, mLevel);
            } else {
               printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : CATObjects ---->>>" + CATObjects);
               this.writeToFileAndSendJob(filePath, (List)CATObjects);
            }

            printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : Writing listTypeData -->> : " + this.listTypeData + " and typepath -->> : " + this.typepath);
            this.writeAnalysedFile(this.listTypeData, this.typepath);
         }
      } catch (Exception var33) {
         xMLLogger.UpdateGlobalStatus("KO");
         xMLLogger.AddGlobalStatusDetailInfo("Error while adding records in file");
         xMLLogger.AddGlobalStatusDetailInfo(var33.getMessage());
         xMLLogger.SaveXFlowXML();
         System.out.println("ERROR : Error while adding CATIA records in file :: " + var33.getMessage());
         printTrace("EDAT_DB_Analyser : AddCATRecordsInFile : Error while adding records in file --> " + var33.getMessage());
      }

      printTrace("EDAT_DB_Analyser : AddCATRecordsInFile ---> End of the method");
   }

   public static String convertToHexa32(String plainText) throws NoSuchAlgorithmException {
      String resultHexa32 = null;
      MessageDigest m = MessageDigest.getInstance("MD5");
      m.reset();
      m.update(plainText.getBytes());
      byte[] digest = m.digest();
      BigInteger bigInt = new BigInteger(1, digest);

      String hashtext;
      for(hashtext = bigInt.toString(16); hashtext.length() < 32; hashtext = "0" + hashtext) {
      }

      resultHexa32 = hashtext.toUpperCase();
      return resultHexa32;
   }

   private void writeToFile(List lstNames, String strPath) {
      if (!lstNames.isEmpty()) {
         this.createFile(strPath, lstNames);
      }

      printTrace("EDAT_DB_Analyser : writeToFile ---> Done");
   }

   private void writeAnalysedFile(List lstNames, String strPath) {
      this.createAnalysedFile(strPath, lstNames);
      printTrace("EDAT_DB_Analyser : writeAnalysedFile ---> Done");
   }

   private void createAnalysedFile(String fileName, List<String> fileContent) {
      printTrace("EDAT_DB_Analyser : createAnalysedFile : fileName ----->>> " + fileName);

      try {
         BufferedWriter writer = null;
         writer = new BufferedWriter(new FileWriter(fileName));

         for(int i = 0; i < fileContent.size(); ++i) {
            writer.write((String)fileContent.get(i));
         }

         writer.close();
      } catch (Exception var9) {
         System.out.println("Error writing in file " + fileName);
         printTrace("EDAT_DB_Analyser : createAnalysedFile ---> Error writing in file : " + fileName + " error:" + var9.getMessage());
      } finally {
         File f = new File(fileName);
         if (fileContent.isEmpty()) {
            f.delete();
         }

      }

   }

   private void writeDataToFiles(String outputFolder, Map<String, List> mCATPart, int fileCount) throws IOException {
      Set<String> keys = mCATPart.keySet();
      Iterator itr = keys.iterator();

      while(itr.hasNext()) {
         String type = (String)itr.next();
         String pathSep = this.getPathSeperator(objAnlayserConfig.getBaseDirectory());
         List<String> outputValues = (List)mCATPart.get(type);
         String tempOutputFolder = outputFolder + pathSep + type + pathSep + fileCount;
         this.validateDirectory(tempOutputFolder);
         tempOutputFolder = tempOutputFolder + pathSep + type + "_" + "Analysis.txt";
         this.createFile(tempOutputFolder, outputValues);
      }

      printTrace("EDAT_DB_Analyser : writeDataToFiles ---> Done");
   }

   private void writeToFileAndSendJob(String temppath, List<String> lstObjects) {
      if (!lstObjects.isEmpty()) {
         List<String> newFiles = this.createFileForImmediateTypes(temppath, lstObjects);
         printTrace("EDAT_DB_Analyser : writeToFileAndSendJob : newFiles ---->>> " + newFiles);

         try {
            for(int count = 0; count < newFiles.size(); ++count) {
               String tempPath = (String)newFiles.get(count);
               printTrace("EDAT_DB_Analyser : writeToFileAndSendJob : tempPath ---->>> " + tempPath);
               this.produce(tempPath, this.threshold);
            }

            this.recoveryXML.AddOperation(this.strAnalysingType, this.operation, this.recoveryId, this.recoveryRev, this.recoveryOriginatedDate);
            this.recoveryXML.SaveRecoveryXML();
            printTrace("EDAT_DB_Analyser : writeToFileAndSendJob ---> JMS Message sent ");
            System.out.println("JMS Message sent");
         } catch (JMSException var6) {
            printTrace("EDAT_DB_Analyser : writeToFileAndSendJob : JMSException is ----> " + var6.getMessage());
            System.out.println("EDAT_DB_Analyser : JMSException while writing files and sending Jobs to Active MQ is ----> " + var6.getMessage());
         } catch (Exception var7) {
            printTrace("EDAT_DB_Analyser : writeToFileAndSendJob : Exception is ----> " + var7.getMessage());
            System.out.println("EDAT_DB_Analyser : Error while writing files and sending Jobs to Active MQ is ----> " + var7.getMessage());
         }
      }

      printTrace("EDAT_DB_Analyser : writeToFileAndSendJob ---> done");
   }

   private void writeAnalysedProdToFiles(List<String> files, Map<Integer, HashMap> mLevel) throws IOException {
      for(int i = 0; i < files.size(); ++i) {
         String path = (String)files.get(i);
         String[] vals = path.split("_");
         int level = Integer.parseInt(vals[vals.length - 1].split("\\\\")[0]);
         HashMap levelMap = (HashMap)mLevel.get(level);
         String[] temp = path.split("\\\\");
         String tempType = temp[temp.length - 3].split("_")[0];
         List<String> levelList = (List)levelMap.get(tempType);
         this.validateDirectory(path);
         String tempPath = path + "\\" + tempType + "_" + level + "_Analysis.txt";
         printTrace("EDAT_DB_Analyser : writeAnalysedProdToFiles : level --->>> " + level + " and tempPath --->>> " + tempPath + " and tempType --->>> " + tempType + " and levelList --->>> " + levelList);
         this.createProdFile(tempPath, levelList);
      }

      printTrace("EDAT_DB_Analyser : writeAnalysedProdToFiles ---> Done");
   }

   public void createFile(String fileName, List<String> fileContent) {
      try {
         this.validateDirectory(fileName);
         fileName = fileName + "\\" + "Export.txt";
         printTrace("EDAT_DB_Analyser : createFile : fileName --->>> " + fileName);
         BufferedWriter writer = null;
         writer = new BufferedWriter(new FileWriter(fileName));

         for(int i = 0; i < fileContent.size(); ++i) {
            writer.write((String)fileContent.get(i));
         }

         writer.close();
      } catch (Exception var5) {
         printTrace("EDAT_DB_Analyser : createFile : Error while writing in file [ " + fileName + " ] ---> " + var5.getMessage());
         System.out.println("Error writing in file " + fileName);
      }

      printTrace("EDAT_DB_Analyser : createFile ---> Done");
   }

   public List<String> createFileForImmediateTypes(String fileName, List<String> fileContent) {
      BufferedWriter writer = null;
      ArrayList<String> newFiles_tmp = new ArrayList();
      List<String> newFiles = new ArrayList();
      newFiles_tmp.addAll(fileContent);

      try {
         this.validateDirectory(fileName);
         List<List<String>> lstOfList = this.splitDuplicateData(newFiles_tmp);
         this.writeSplitFiles(fileName, this.threshold, newFiles, lstOfList, false);
         if ("ON".equals(objAnlayserConfig.getCloudMigration())) {
            this.writePathListFile(objAnlayserConfig.getBaseDirectory(), this.strAnalysingType, newFiles);
         }

         return newFiles;
      } catch (Exception var7) {
         printTrace("EDAT_DB_Analyser : createFileForImmediateTypes : Error while writing in file [ " + fileName + " ] ---> " + var7.getMessage());
         System.out.println("Error while creating file for immeadiatetypes " + fileName);
         printTrace("EDAT_DB_Analyser : createFileForImmediateTypes ---> Done");
         return newFiles;
      }
   }

   private List<List<String>> splitDuplicateData(ArrayList<String> fileContent) {
      ArrayList lstOfList = new ArrayList();

      try {
         int lstCount = fileContent.size();
         int originalCount = lstCount;
         Map<String, List<String>> mpData = this.getMapData(fileContent);
         new ArrayList();

         Iterator itr;
         for(int totalCount = 0; totalCount != originalCount; itr = mpData.keySet().iterator()) {
            itr = mpData.keySet().iterator();
            ArrayList tempList = new ArrayList();

            while(itr.hasNext()) {
               String key = (String)itr.next();
               List<String> lstValue = (List)mpData.get(key);
               if (lstValue.size() > 0) {
                  tempList.add(lstValue.get(0));
                  ++totalCount;
                  lstValue.remove(0);
                  mpData.put(key, lstValue);
               }
            }

            if (!tempList.isEmpty()) {
               lstOfList.add(tempList);
            }
         }
      } catch (Exception var11) {
         printTrace("EDAT_DB_Analyser : splitDuplicateData : Error splitting duplicate date : -->>> " + var11.getMessage());
         System.out.println("Error: Error while splitting duplicate date : -->>>  " + var11.getMessage());
      }

      printTrace("EDAT_DB_Analyser : splitDuplicateData : lstOfList --->>>> " + lstOfList);
      return lstOfList;
   }

   public void createProdFile(String fileName, List<String> fileContent) {
      try {
         BufferedWriter writer = null;
         writer = new BufferedWriter(new FileWriter(fileName));
         Collections.sort(fileContent, new EDAT_DateComparator());

         for(int i = 0; i < fileContent.size(); ++i) {
            writer.write((String)fileContent.get(i));
         }

         writer.close();
      } catch (Exception var5) {
         System.out.println("Error writing in file " + fileName);
         printTrace("EDAT_DB_Analyser : createProdFile : Error while writing in file [ " + fileName + " ] ---> " + var5.getMessage());
      }

   }

   public String getPathSeperator(String path) {
      String sSlash = "\\";
      if (path != null && path.contains("/")) {
         sSlash = "/";
      }

      return sSlash;
   }

   public Map getMapData(ArrayList<String> lstAllData) {
      Map<String, List<String>> mapData = new HashMap();
      new ArrayList();

      for(int i = 0; i < lstAllData.size(); ++i) {
         String strLine = (String)lstAllData.get(i);
         String[] line = strLine.split(",");
         String typeName = line[1] + "," + line[3];
         if (mapData.containsKey(typeName)) {
            List<String> lst = (List)mapData.get(typeName);
            lst.add(strLine);
            mapData.put(typeName, lst);
         } else {
            List<String> lst = new ArrayList();
            lst.add(strLine);
            mapData.put(typeName, lst);
         }
      }

      printTrace("EDAT_DB_Analyser : getMapData : mapData --->>>> : " + mapData);
      return mapData;
   }

   public List<List<String>> getSplitListFromFile(String path, double threshold) {
      ArrayList lstOfList = new ArrayList();

      try {
         ArrayList<String> lstAllData = this.GetAllLines(path);
         int lstCount = lstAllData.size();
         int originalCount = lstCount;
         Map<String, List<String>> mpData = this.getMapData(lstAllData);
         new ArrayList();

         Iterator itr;
         for(int totalCount = 0; totalCount != originalCount; itr = mpData.keySet().iterator()) {
            itr = mpData.keySet().iterator();
            int cnt = 0;
            ArrayList tempList = new ArrayList();

            while((double)cnt < threshold && itr.hasNext()) {
               String key = (String)itr.next();
               List<String> lstValue = (List)mpData.get(key);
               if (lstValue.size() > 0) {
                  tempList.add(lstValue.get(0));
                  ++cnt;
                  ++totalCount;
                  lstValue.remove(0);
                  mpData.put(key, lstValue);
               }
            }

            if (!tempList.isEmpty()) {
               lstOfList.add(tempList);
            }
         }
      } catch (Exception var15) {
         printTrace("EDAT_DB_Analyser : getSplitListFromFile : Error ----> " + var15.getMessage());
         System.out.println("Exception is : ---> " + var15.getMessage());
      }

      printTrace("EDAT_DB_Analyser : getSplitListFromFile : lstOfList --->>>> " + lstOfList);
      return lstOfList;
   }

   public List<String> splitFile(String path, double threshold, boolean isFailed) {
      ArrayList newFiles = new ArrayList();

      try {
         List<List<String>> lstofList = this.getSplitListFromFile(path, threshold);
         this.writeSplitFiles(path, threshold, newFiles, lstofList, true);
         if ("ON".equals(objAnlayserConfig.getCloudMigration())) {
            this.writePathListFile(objAnlayserConfig.getBaseDirectory(), this.strAnalysingType, newFiles);
         }
      } catch (Exception var7) {
         printTrace("EDAT_DB_Analyser : splitFile : Error ----> " + var7.getMessage());
         System.out.println("EDAT_DB_Analyser : Error while split file : " + var7.getMessage());
         var7.printStackTrace();
      }

      printTrace("EDAT_DB_Analyser : splitFile : newFiles --->> :" + newFiles);
      return newFiles;
   }

   private void writeSplitFiles(String path, double threshold, List<String> newFiles, List<List<String>> lstofList, boolean immediateTypesData) throws IOException {
      printTrace("EDAT_DB_Analyser : writeSplitFiles ------->");
      File file = new File(path);
      String parentDir = file.getParent();

      for(int j = 0; j < lstofList.size(); ++j) {
         String temppath = parentDir + "\\" + j;
         if (!immediateTypesData) {
            temppath = parentDir + "\\" + this.fileCount;
            printTrace("EDAT_DB_Analyser : writeSplitFiles : temppath ----->>> " + temppath);
            ++this.fileCount;
         }

         this.validateDirectory(temppath);
         temppath = temppath + "\\" + "Export.txt";
         printTrace("EDAT_DB_Analyser : writeSplitFiles : temppath ----->>> " + temppath);
         FileWriter fstream1 = new FileWriter(temppath);
         newFiles.add(temppath);
         BufferedWriter out = new BufferedWriter(fstream1);
         List<String> lstOfData = (List)lstofList.get(j);

         for(int i = 0; i < lstOfData.size(); ++i) {
            String strLine = (String)lstOfData.get(i);
            if (strLine != null) {
               out.write(strLine);
               if (immediateTypesData && (double)i != threshold) {
                  out.newLine();
               }
            }
         }

         this.ExportPathList.add(temppath + "\n");
         out.close();
      }

   }

   private ArrayList<String> GetAllLines(String path) throws IOException {
      BufferedReader bufReader = new BufferedReader(new FileReader(path));
      ArrayList<String> listOfLines = new ArrayList();

      for(String line = bufReader.readLine(); line != null; line = bufReader.readLine()) {
         listOfLines.add(line);
      }

      bufReader.close();
      return listOfLines;
   }

   private void writeAnalyserStatus_OK(MapList mlResults) throws Exception {
      new EDAT_AnalyserBusinessDAO();
      ConnectionFactory factory = new ActiveMQConnectionFactory(this.getParamaterValueFromXML(this.doc, "ActiveMQPath"));
      Connection connection = null;
      Session session = null;
      String messageText = "";

      try {
         connection = factory.createConnection();
         session = connection.createSession(true, 0);
         Destination destination = session.createQueue("ANALYSER_STATUS");
         MessageProducer producer = session.createProducer(destination);
         producer.setDeliveryMode(2);

         for(int i = 0; i < mlResults.size(); ++i) {
            TextMessage message = session.createTextMessage();
            Map mpData = (Map)mlResults.get(i);
            String tempType = (String)mpData.get("type");
            String tempName = (String)mpData.get("name");
            String tempRev = (String)mpData.get("revision");
            String strModified = (String)mpData.get("modified");
            String strLevel = (String)mpData.get("level");
            printTrace("EDAT_DB_Analyser : writeAnalyserStatus_OK : strLevel ---> " + strLevel);
            String tempFileFormat = this.getFileFormat(mpData, "|");
            if ("NONCAD".equalsIgnoreCase(objAnlayserConfig.getCADType())) {
               if (tempFileFormat.contains("|")) {
                  tempFileFormat = tempFileFormat.replace("|", ";");
               }

               strLevel = "1";
            }

            String idCreation = tempType + "_" + tempName + "_" + tempRev;
            idCreation = convertToHexa32(idCreation);
            String output = tempName + "," + tempType + "," + tempRev + "," + tempFileFormat + "\n";
            if (!EDAT_AnalyserBusinessInterface.lstMissingFilesNames.contains(output) && !EDAT_AnalyserBusinessInterface.lstInvalidNames.contains(output) && !EDAT_AnalyserBusinessInterface.lstHavingSpaceFilesNames.contains(output) && !EDAT_AnalyserBusinessInterface.lstFilenameLenGT100Char.contains(output)) {
               messageText = "<Message><Operation>Export</Operation><ROOT_NODE_PATH/><ID>" + idCreation + "</ID><Revision>" + tempRev + "</Revision><Standard>False</Standard><RootAssembly/><modificationtime>" + strModified + "</modificationtime><fileName>" + tempFileFormat + "</fileName><STATUS>Analysis OK</STATUS><RESPONSE>Analyser Successful</RESPONSE><PLMEXTERNALID>" + tempName + "</PLMEXTERNALID><LEVEL>" + strLevel + "</LEVEL></Message>";
               printTrace("EDAT_DB_Analyser : writeAnalyserStatus_OK : messageText ----->>> " + messageText);
               byte[] b = messageText.getBytes(StandardCharsets.UTF_8);
               String sText = new String(b, StandardCharsets.UTF_8);
               message.setText(sText);
               producer.send(message);
               session.commit();
               message.getJMSMessageID();
            }
         }
      } catch (Exception var25) {
         printTrace("EDAT_DB_Analyser : writeAnalyserStatus_OK --- Error while creating the dashboard message" + var25.getMessage());
         throw new Exception("Error while creating the dashboard message" + var25.getMessage());
      } finally {
         closeSilently(connection, session);
      }

      printTrace("EDAT_DB_Analyser : writeAnalyserStatus_OK ---> Done");
   }

   private void writeAnalyserStatus_KO() throws Exception {
      new EDAT_AnalyserBusinessDAO();
      ConnectionFactory factory = new ActiveMQConnectionFactory(this.getParamaterValueFromXML(this.doc, "ActiveMQPath"));
      Connection connection = null;
      Session session = null;
      String messageText = "";

      try {
         connection = factory.createConnection();
         session = connection.createSession(true, 0);
         Destination destination = session.createQueue("ANALYSER_STATUS");
         MessageProducer producer = session.createProducer(destination);
         producer.setDeliveryMode(2);

         int i;
         TextMessage message;
         String oneItem;
         String[] fields;
         String idCreation;
         byte[] b;
         String sText;
         for(i = 0; i < EDAT_AnalyserBusinessInterface.lstMissingFilesNames.size(); ++i) {
            message = session.createTextMessage();
            oneItem = EDAT_AnalyserBusinessInterface.lstMissingFilesNames.get(i).toString();
            fields = oneItem.split(",");
            idCreation = fields[1] + "_" + fields[0] + "_" + fields[2];
            idCreation = convertToHexa32(idCreation);
            messageText = "<Message><Operation>Export</Operation><ROOT_NODE_PATH/><ID>" + idCreation + "</ID><Revision>" + fields[2] + "</Revision><Standard/><RootAssembly/><modificationtime/><fileName/><STATUS>Analysis KO</STATUS><RESPONSE>Missing File</RESPONSE><PLMEXTERNALID>" + fields[0] + "</PLMEXTERNALID></Message>";
            printTrace("EDAT_DB_Analyser : writeAnalyserStatus_KO : messageText ----->>> " + messageText);
            b = messageText.getBytes(StandardCharsets.UTF_8);
            sText = new String(b, StandardCharsets.UTF_8);
            message.setText(sText);
            producer.send(message);
            session.commit();
            message.getJMSMessageID();
         }

         for(i = 0; i < EDAT_AnalyserBusinessInterface.lstInvalidNames.size(); ++i) {
            message = session.createTextMessage();
            oneItem = EDAT_AnalyserBusinessInterface.lstInvalidNames.get(i).toString();
            fields = oneItem.split(",");
            idCreation = fields[1] + "_" + fields[0] + "_" + fields[2];
            idCreation = convertToHexa32(idCreation);
            messageText = "<Message><Operation>Export</Operation><ROOT_NODE_PATH/><ID>" + idCreation + "</ID><Revision>" + fields[2] + "</Revision><Standard/><RootAssembly/><modificationtime/><fileName/><STATUS>Analysis KO</STATUS><RESPONSE>Invalid Char</RESPONSE><PLMEXTERNALID>" + fields[0] + "</PLMEXTERNALID></Message>";
            printTrace("EDAT_DB_Analyser : writeAnalyserStatus_KO : messageText ----->>> " + messageText);
            b = messageText.getBytes(StandardCharsets.UTF_8);
            sText = new String(b, StandardCharsets.UTF_8);
            message.setText(sText);
            producer.send(message);
            session.commit();
            message.getJMSMessageID();
         }

         for(i = 0; i < EDAT_AnalyserBusinessInterface.lstHavingSpaceFilesNames.size(); ++i) {
            message = session.createTextMessage();
            oneItem = EDAT_AnalyserBusinessInterface.lstHavingSpaceFilesNames.get(i).toString();
            fields = oneItem.split(",");
            idCreation = fields[1] + "_" + fields[0] + "_" + fields[2];
            idCreation = convertToHexa32(idCreation);
            messageText = "<Message><Operation>Export</Operation><ROOT_NODE_PATH/><ID>" + idCreation + "</ID><Revision>" + fields[2] + "</Revision><Standard/><RootAssembly/><modificationtime/><fileName/><STATUS>Analysis KO</STATUS><RESPONSE>Spaces present in Filename</RESPONSE><PLMEXTERNALID>" + fields[0] + "</PLMEXTERNALID></Message>";
            printTrace("EDAT_DB_Analyser : writeAnalyserStatus_KO : messageText ----->>> " + messageText);
            b = messageText.getBytes(StandardCharsets.UTF_8);
            sText = new String(b, StandardCharsets.UTF_8);
            message.setText(sText);
            producer.send(message);
            session.commit();
            message.getJMSMessageID();
         }

         for(i = 0; i < EDAT_AnalyserBusinessInterface.lstFilenameLenGT100Char.size(); ++i) {
            message = session.createTextMessage();
            oneItem = EDAT_AnalyserBusinessInterface.lstFilenameLenGT100Char.get(i).toString();
            fields = oneItem.split(",");
            idCreation = fields[1] + "_" + fields[0] + "_" + fields[2];
            idCreation = convertToHexa32(idCreation);
            messageText = "<Message><Operation>Export</Operation><ROOT_NODE_PATH/><ID>" + idCreation + "</ID><Revision>" + fields[2] + "</Revision><Standard/><RootAssembly/><modificationtime/><fileName/><STATUS>Analysis KO</STATUS><RESPONSE>FileName contains more than 100 character</RESPONSE><PLMEXTERNALID>" + fields[0] + "</PLMEXTERNALID></Message>";
            printTrace("EDAT_DB_Analyser : writeAnalyserStatus_KO : messageText ----->>> " + messageText);
            b = messageText.getBytes(StandardCharsets.UTF_8);
            sText = new String(b, StandardCharsets.UTF_8);
            message.setText(sText);
            producer.send(message);
            session.commit();
            message.getJMSMessageID();
         }
      } catch (Exception var18) {
         printTrace("EDAT_DB_Analyser : writeAnalyserStatus_KO --> Error while creating the dashboard message" + var18.getMessage());
         throw new Exception("Error while creating the dashboard message" + var18.getMessage());
      } finally {
         closeSilently(connection, session);
      }

      printTrace("EDAT_DB_Analyser : writeAnalyserStatus_KO ---> Done");
   }

   public void failDataClearance(Context context, File fileFailureList) {
      List failedList = new ArrayList();
      String strLine = null;
      Map map = null;
      EDAT_DBService dbService = null;

      try {
         BufferedReader br = new BufferedReader(new FileReader(fileFailureList));

         while((strLine = br.readLine()) != null) {
            String[] line = strLine.split(",");
            failedList.add(line[0]);
         }

         dbService = new EDAT_DBService();
         dbService.connectToDB();

         for(int i = 0; i < failedList.size(); ++i) {
            dbService.deleteCloudFailedFromTable(failedList.get(i).toString());
         }

         dbService.closeConnection();
      } catch (Exception var10) {
         printTrace("EDAT_DB_Analyser : failDataClearance -->Error in FailCase file access:  " + var10.getMessage());
         System.out.println("Error in FailCase file access: " + var10.getMessage());
      }

   }

   public void writePathListFile(String path, String type, List<String> newFiles) {
      try {
         String strPathListFileName = type + "_pathlist.txt";
         File filePathList = new File(path + File.separator + strPathListFileName);
         filePathList.createNewFile();
         FileWriter fw = new FileWriter(filePathList, true);
         BufferedWriter bw = new BufferedWriter(fw);
         if (!newFiles.isEmpty()) {
            for(int intPathCounter = 0; intPathCounter < newFiles.size(); ++intPathCounter) {
               String exportFilePath = (String)newFiles.get(intPathCounter);
               bw.write(exportFilePath);
               bw.newLine();
            }
         }

         bw.close();
      } catch (Exception var10) {
         printTrace("EDAT_DB_Analyser : writePathListFile ---> Error in PathLis :  " + var10.getMessage());
         System.out.println("Error in PathList: " + var10.getMessage());
      }

   }

   public void addKOStatusToXflowXML(StringList sList) {
      String duration = "";
      long xFlowDuration = (System.currentTimeMillis() - this.xFlowStartTime) / 1000L;
      long hours = xFlowDuration / 3600L;
      long minutes = xFlowDuration % 3600L / 60L;
      long seconds = xFlowDuration % 60L;
      duration = String.format("%02dhr:%02dmin:%02dsec", hours, minutes, seconds);

      try {
         if (!sList.isEmpty()) {
            for(int i = 0; i < sList.size(); ++i) {
               String data = (String)sList.get(i);
               String[] arr = data.split(",");
               String type = arr[0];
               String name = arr[1];
               String rev = arr[2];
               String objId = arr[3].trim();
               xMLLogger.AddObjectStatusNode(objId, type, "KO", duration);
               xMLLogger.AddObjectStatusDetailInfo(objId, "Analysis of Object " + name + " " + rev + " " + "KO");
            }
         }

         xMLLogger.SaveXFlowXML();
      } catch (Exception var18) {
         loggedXflowGlobalStatus(xMLLogger, "KO", "Error while adding invalid records in file" + var18.getMessage());
         printTrace("EDAT_DB_Analyser :  addKOStatusToXflowXML --> Error while adding invalid records in file  : " + var18.getMessage());
         System.out.println("ERROR : Error while adding invalid records in file");
      }

      printTrace("EDAT_DB_Analyser : addKOStatusToXflowXML ---> Done");
   }

   private void readSkipObjectsFile(String strSkipObject) throws IOException {
      printTrace("EDAT_DB_Analyser : readSkipObjectsFile : strSkipObject --->>>> " + strSkipObject);
      String skipFilepath = objAnlayserConfig.getDecodedPropertiesPath() + File.separator + "config" + File.separator + "SkipObjects.txt";
      new EDAT_AnalyserBusinessDAO();
      new ArrayList();
      List<String> skipfiledata = Files.readAllLines(Paths.get(skipFilepath), StandardCharsets.UTF_8);
      Iterator var6 = skipfiledata.iterator();

      while(var6.hasNext()) {
         String s = (String)var6.next();
         EDAT_AnalyserBusinessDAO.lstSkipObjects.add(s);
      }

      printTrace("EDAT_DB_Analyser : readSkipObjectsFile : lstSkipObjects --->>>> " + EDAT_AnalyserBusinessDAO.lstSkipObjects);
   }

   public static void printTrace(String msg) {
      if (traceOn) {
         DTKLogger.PrintLog(msg);
      }

   }

   private List<Character> convertStringToCharList(String invalidChar) {
      List<Character> chars = new ArrayList();
      char[] var6;
      int var5 = (var6 = invalidChar.toCharArray()).length;

      for(int var4 = 0; var4 < var5; ++var4) {
         char ch = var6[var4];
         chars.add(ch);
      }

      return chars;
   }

   private String currentDateTime() {
      long time = System.currentTimeMillis();
      DateFormat simple = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS Z");
      Date date = new Date(time);
      String strDateTime = simple.format(date);
      return strDateTime;
   }

   private void addNonCADDataInFile(MapList mapFinal) {
      printTrace("EDAT_DB_Analyser : addNonCADDataInFile ---> Start of the method" + mapFinal);
      new EDAT_AnalyserBusinessDAO();
      this.mlResults = mapFinal;
      mapFinal.addSortKey("originated", "ascending", "date");
      mapFinal.sort();
      Object var3 = null;

      try {
         printTrace("EDAT_DB_Analyser : AddNonCADDataInFile : mapFinal is ----->>>> " + mapFinal);
         StringList nonCADdata = new StringList();
         new HashMap();
         String filePath = "";
         String tempType = "";
         String tempName = "";
         String tempRev = "";
         String tempCurrent = "";
         String tempObjectId = "";
         String strOriginated = "";
         String strDuration = "";

         for(int i = 0; i < mapFinal.size(); ++i) {
            Map mpData = (Map)mapFinal.get(i);
            tempType = (String)mpData.get("type");
            tempName = (String)mpData.get("name");
            tempRev = (String)mpData.get("revision");
            tempCurrent = (String)mpData.get("current");
            tempObjectId = (String)mpData.get("id");
            strOriginated = (String)mpData.get("originated");
            if (!tempRev.contains(".")) {
               String tempFileFormat = this.getFileFormat(mpData, "|");
               this.recoveryId = tempObjectId;
               this.recoveryOriginatedDate = strOriginated;
               this.recoveryRev = tempRev;
               String output = tempType + "," + tempName + "," + tempRev + "," + tempFileFormat + "," + tempCurrent + "," + strOriginated + "," + tempObjectId + "\n";
               this.listTypeData.add(output);
               filePath = objAnlayserConfig.getBaseDirectory() + "/" + tempType + "/" + this.strPath + "/" + this.fileCount;
               nonCADdata.add(output);
               long xFlowEndTime = (System.currentTimeMillis() - this.xFlowStartTime) / 1000L;
               long hours = xFlowEndTime / 3600L;
               long minutes = xFlowEndTime % 3600L / 60L;
               long seconds = xFlowEndTime % 60L;
               strDuration = String.format("%02dhr:%02dmin:%02dsec", hours, minutes, seconds);
               xMLLogger.AddObjectStatusNode(tempObjectId, tempType, "OK", strDuration);
               xMLLogger.AddObjectStatusDetailInfo(tempObjectId, "Analysis of Object " + tempName + " " + tempRev + " " + "OK");
            }

            xMLLogger.SaveXFlowXML();
         }

         this.writeAnalysedFile(this.listTypeData, this.typepath);
         printTrace("EDAT_DB_Analyser : addNonCADDataInFile : Writting listTypeData -->> : " + this.listTypeData + " and typepath -->> : " + this.typepath);
         this.writeToFileAndSendJob(filePath, nonCADdata);
      } catch (Exception var26) {
         loggedXflowGlobalStatus(xMLLogger, "KO", "Error while adding records in file" + var26.getMessage());
         System.out.println("ERROR : Error while adding NONCAD records in file :: " + var26.getMessage());
         printTrace("EDAT_DB_Analyser : AddNonCADDataInFile  : Error while adding records in file --> " + var26.getMessage());
      }

      printTrace("EDAT_DB_Analyser : AddNonCADDataInFile ---> End of the method");
   }

   MapList analyzeNonImmediateTypes(Context context, Map mpAssembly, MapList mlChildData, String busid, int level, StringList slChildProcessedList, String strAnalysingType, String type) throws Exception {
      printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : strAnalysingType ----->>> " + strAnalysingType);
      LinkedHashSet slAssemblyChild = new LinkedHashSet();
      StringList slAssemblyChild1 = new StringList();
      Map childofchild = null;
      String childofchildLevel = null;
      String childBusId = null;
      String childType = null;
      MapList mlProd = null;
      new HashMap();
      EDAT_AnalyserBusinessInterface anlyserObj = new EDAT_AnalyserBusinessDAO();
      printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : slProcessedList ----->>> " + this.slProcessedList);
      if (!this.slProcessedList.contains(busid)) {
         Map<String, StringList> resultMap = this.setPartListAndConnObjType(mpAssembly, objAnlayserConfig.isGrtThan15x(), strAnalysingType);
         StringList slPartList = (StringList)resultMap.get("slPartList");
         StringList slConnObjType = (StringList)resultMap.get("slConnObjType");
         printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : slPartList ----->>> " + slPartList);
         printTrace("EDAT_DB_Analyser : analyseCATProduct : slConnObjType ----->>> " + slConnObjType);
         if (slConnObjType != null && slConnObjType.size() > 0) {
            slAssemblyChild.addAll(slPartList);
            slAssemblyChild1.addAll(slAssemblyChild);
            printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : slAssemblyChild1 ----->>> " + slAssemblyChild1);
            if (slAssemblyChild1.size() > 0) {
               int iAssemblyLevel = level + 1;
               if (this.isSelectiveMode) {
                  Iterator iterator = slAssemblyChild1.iterator();

                  while(iterator.hasNext()) {
                     String childId = (String)iterator.next();
                     if (this.allCATPartsBusId.contains(childId)) {
                        iterator.remove();
                     }
                  }

                  printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : slAssemblyChild1 ----->>> " + slAssemblyChild1);
               }

               mlProd = anlyserObj.getRootObjectDetails(context, slAssemblyChild1, strAnalysingType, this.isSelectiveMode);
               this.addLevelValue(mlProd, iAssemblyLevel);
               mlChildData.addAll(mlProd);
               printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : mlChildData ----->>> " + mlChildData);
               int mlProdSize = mlProd.size();
               printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : mlProdSize ----->>> " + mlProdSize);

               for(int a = 0; a < mlProdSize; ++a) {
                  childofchild = (Map)mlProd.get(a);
                  childBusId = (String)childofchild.get("id");
                  childType = (String)childofchild.get("type");
                  if (type.equalsIgnoreCase("SW Assembly Family")) {
                     this.SWAssemblyCyclicDataCheck(childofchild, objAnlayserConfig.isGrtThan15x());
                  }

                  printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : childofchild ----->>> " + childofchild);
                  printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : childBusId , childType ----->>> " + childofchild + " , " + childType);
                  if (slChildProcessedList.contains(childBusId)) {
                     System.out.println("Cyclic Data Found for object id : " + childBusId + " in root assembly");
                     throw new Exception("Cyclic Data Found");
                  }

                  slChildProcessedList.add(childBusId);
                  childofchildLevel = (String)childofchild.get("level");
                  printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : slChildProcessedList ----->>> " + slChildProcessedList);
                  this.analyzeNonImmediateTypes(context, childofchild, mlChildData, childBusId, Integer.parseInt(childofchildLevel), slChildProcessedList, childType, type);
                  slChildProcessedList.remove(childBusId);
               }
            }
         }
      }

      printTrace("EDAT_DB_Analyser : analyzeNonImmediateTypes : mlChildData ----->>> " + mlChildData);
      return mlChildData;
   }

   private Map<String, StringList> setPartListAndConnObjType(Map mpAssembly, boolean greaterThan15x, String type) {
      printTrace("EDAT_DB_Analyser : setPartListAndConnObjType : mpAssembly ----->>> " + mpAssembly);
      printTrace("EDAT_DB_Analyser : setPartListAndConnObjType : type ----->>> " + type);
      Map<String, StringList> resultMap = new HashMap();
      StringList slPartList = new StringList();
      StringList slEmbeddedComp = new StringList();
      StringList slEmbeddedCompOther = new StringList();
      StringList slConnObjType = new StringList();
      if ("CATProduct".equalsIgnoreCase(type) || "INV Assembly".equalsIgnoreCase(type) || "INV Assembly Factory".equalsIgnoreCase(type) || "UG Assembly".equalsIgnoreCase(type) || type.equalsIgnoreCase("CATIA Embedded Component") || "ProE Assembly".equalsIgnoreCase(type)) {
         if (!greaterThan15x && (type.equalsIgnoreCase("CATProduct") || type.equalsIgnoreCase("CATIA Embedded Component"))) {
            slPartList = getObjectDetailList(mpAssembly.get("from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to[CATProduct].id"));
            if (type.equalsIgnoreCase("CATIA Embedded Component")) {
               slEmbeddedComp = getObjectDetailList(mpAssembly.get("from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to[CATProduct].id"));
               slEmbeddedCompOther = getObjectDetailList(mpAssembly.get("from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to[CATIA Embedded Component].id"));
            } else {
               slEmbeddedComp = getObjectDetailList(mpAssembly.get("from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to[CATIA Embedded Component].id"));
            }

            slConnObjType = getObjectDetailList(mpAssembly.get("from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to.type"));
            slPartList.addAll(slEmbeddedComp);
            slPartList.addAll(slEmbeddedCompOther);
         } else {
            if (this.isSelectiveMode) {
               slPartList = getObjectDetailList(mpAssembly.get("from[CAD SubComponent].to.id"));
            } else {
               slPartList = getObjectDetailList(mpAssembly.get("from[CAD SubComponent].to[" + type + "].id"));
            }

            if (type.startsWith("CAT")) {
               if (type.equalsIgnoreCase("CATIA Embedded Component")) {
                  slEmbeddedComp = getObjectDetailList(mpAssembly.get("from[CAD SubComponent].to[CATProduct].id"));
               } else {
                  slEmbeddedComp = getObjectDetailList(mpAssembly.get("from[CAD SubComponent].to[CATIA Embedded Component].id"));
               }
            }

            slConnObjType = getObjectDetailList(mpAssembly.get("from[CAD SubComponent].to.type"));
            slPartList.addAll(slEmbeddedComp);
         }

         printTrace("EDAT_DB_Analyser : setPartListAndConnObjType : slEmbeddedComp ----->>> " + slEmbeddedComp);
      }

      if ("SW Assembly Family".equalsIgnoreCase(type)) {
         if (!greaterThan15x) {
            slPartList = getObjectDetailList(mpAssembly.get("from[Active Version].to.from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.to[Active Version].from[SW Assembly Family].id"));
            slConnObjType = getObjectDetailList(mpAssembly.get("from[Active Version].to.from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.to[Active Version].from.type"));
         } else {
            slPartList = getObjectDetailList(mpAssembly.get("from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from[SW Assembly Family].id"));
            slConnObjType = getObjectDetailList(mpAssembly.get("from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.type"));
         }
      }

      resultMap.put("slPartList", slPartList);
      resultMap.put("slConnObjType", slConnObjType);
      printTrace("EDAT_DB_Analyser : setPartListAndConnObjType : resultMap ----->>> " + resultMap);
      return resultMap;
   }

   public Map levelUpdate(MapList mlCurrentMap, String baseDir) {
      printTrace("EDAT_DB_Analyser : analyser ---> Level calculation Start ");
      Map mFillMap = new HashMap();
      String busId = "";
      String type = "";
      String name = "";
      String revision = "";
      String fileName = "";
      String description = "";
      EDAT_AnalyserBusinessInterface anlyserObj = new EDAT_AnalyserBusinessDAO();
      boolean fCleanDataCheck = true;

      for(int i = 0; i < mlCurrentMap.size(); ++i) {
         Map currentMap = (HashMap)mlCurrentMap.get(i);
         printTrace("EDAT_DB_Analyser : levelUpdate : currentMap ---> " + currentMap);
         busId = (String)currentMap.get("id");
         type = (String)currentMap.get("type");
         name = (String)currentMap.get("name");
         revision = (String)currentMap.get("revision");
         fileName = this.getFileFormat(currentMap, "|");
         description = (String)currentMap.get("description");
         printTrace("EDAT_DB_Analyser : levelUpdate ---> fileName ---> " + fileName);
         fCleanDataCheck = anlyserObj.cleanDataCheck(type, name, revision, fileName, busId, description, baseDir, this.lstTypes);
         printTrace("EDAT_DB_Analyser : levelUpdate ---> fCleanDataCheck ---> " + fCleanDataCheck);
         description = "";
         if (fCleanDataCheck) {
            printTrace("EDAT_DB_Analyser : levelUpdate ---> mFinal ---> " + this.mFinal);
            printTrace("EDAT_DB_Analyser : levelUpdate ---> busId ---> " + busId);
            if (this.mFinal.containsKey(busId)) {
               Map previousMap = (Map)this.mFinal.get(busId);
               int oldLevel = Integer.parseInt((String)previousMap.get("level"));
               int newLevel = Integer.parseInt((String)currentMap.get("level"));
               printTrace("EDAT_DB_Analyser : levelUpdate ---> oldLevel ---> " + oldLevel + " , newLevel --> " + newLevel);
               if (newLevel > oldLevel) {
                  this.mFinal.put(busId, (HashMap)currentMap);
                  mFillMap.put(busId, currentMap);
               }
            } else {
               this.mFinal.put(busId, (HashMap)currentMap);
               mFillMap.put(busId, currentMap);
            }
         }
      }

      printTrace("EDAT_DB_Analyser : analyser ---> Level calculation End ");
      return mFillMap;
   }

   private String getFileFormat(Map mpData, String serprator) {
      String tempFileFormat = "";
      StringList slFileFormat = new StringList();
      Object formatHasFileValue = mpData.get("format.hasfile");
      int formatCount;
      if (formatHasFileValue != null && (formatHasFileValue instanceof String && ("True".equalsIgnoreCase((String)formatHasFileValue) || ((String)formatHasFileValue).contains("True")) || formatHasFileValue instanceof StringList && ((StringList)formatHasFileValue).contains("TRUE"))) {
         printTrace("EDAT_DB_Analyser : getFileFormat : If 'FORMAT_HASFILE' is TRUE ---->>>>");
         if (mpData.get("format.file.name") instanceof String) {
            slFileFormat.add((String)mpData.get("format.file.name"));
         } else if (mpData.get("format.file.name") instanceof StringList) {
            slFileFormat = (StringList)mpData.get("format.file.name");
         }

         for(formatCount = 0; formatCount < slFileFormat.size(); ++formatCount) {
            if (UIUtil.isNullOrEmpty(tempFileFormat)) {
               tempFileFormat = (String)slFileFormat.get(formatCount);
            } else {
               tempFileFormat = tempFileFormat + serprator + slFileFormat.get(formatCount);
            }
         }
      }

      if (UIUtil.isNullOrEmpty(tempFileFormat) && (String)mpData.get("from[Active Version].to.format.hasfile") != null && "True".equalsIgnoreCase((String)mpData.get("from[Active Version].to.format.hasfile"))) {
         printTrace("EDAT_DB_Analyser : getFileFormat : 'FROM_ACTIVE_VERSION_TO_FORMAT_HASFILE' is TRUE ---->>>");
         if (mpData.get("from[Active Version].to.format.file.name") instanceof String) {
            slFileFormat.add((String)mpData.get("from[Active Version].to.format.file.name"));
         } else if (mpData.get("from[Active Version].to.format.file.name") instanceof StringList) {
            slFileFormat = (StringList)mpData.get("from[Active Version].to.format.file.name");
         }

         for(formatCount = 0; formatCount < slFileFormat.size(); ++formatCount) {
            if (UIUtil.isNullOrEmpty(tempFileFormat)) {
               tempFileFormat = (String)slFileFormat.get(formatCount);
            } else {
               tempFileFormat = tempFileFormat + serprator + slFileFormat.get(formatCount);
            }
         }
      }

      printTrace("EDAT_DB_Analyser : getFileFormat : tempFileFormat ------>>>>>" + tempFileFormat);
      return tempFileFormat;
   }

   private String getUTCDateTime(String modified) {
      String utcDate = "";

      try {
         DateFormat formatterUTC = new SimpleDateFormat("M/d/yyyy h:mm:ss a", Locale.ENGLISH);
         Date date = formatterUTC.parse(modified);
         formatterUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
         utcDate = formatterUTC.format(date);
      } catch (ParseException var5) {
         printTrace("EDAT_DB_Analyser : getUTCDateTime ---> ParseException ::  " + var5.getMessage());
         System.out.println("EDAT_DB_Analyser : ParseException while getting the UTCDate and Time : --> " + var5.getMessage());
      }

      printTrace("EDAT_DB_Analyser : getUTCDateTime : utcDate --->>>" + utcDate);
      return utcDate;
   }

   private List<String> readFileWithFallback(String filePath) throws Exception {
      try {
         return Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
      } catch (Exception var3) {
         if (var3.getMessage() != null && var3.getMessage().contains("Input length = 1")) {
            printTrace("EDAT_DB_Analyser : readFileWithFallback ---> UTF-8 decoding failed :  " + var3.getMessage());
            System.out.println("UTF-8 decoding failed and using ISO_8859_1 : " + var3.getMessage());
            return Files.readAllLines(Paths.get(filePath), StandardCharsets.ISO_8859_1);
         } else {
            printTrace("EDAT_DB_Analyser : readFileWithFallback ---> Exception while Reading files/Encoding ::  " + var3.getMessage());
            System.out.println("Exception while Reading files/Encoding : " + var3.getMessage());
            throw var3;
         }
      }
   }

   private Map<String, Map<String, String>> analyzeCATDrawing(Context context, Map<String, String> rootMap, MapList mlChildData, String busId_temp, String type, String baseDir, Map<String, Map<String, String>> mFillMap) throws Exception {
      printTrace("EDAT_DB_Analyser : analyser: analyzeCATDrawing ----> Start of the method ");
      EDAT_AnalyserBusinessInterface anlyserObj = new EDAT_AnalyserBusinessDAO();
      new StringList();
      String slDrgConnObjType = null;
      MapList mlProd = null;
      StringList slChildProcessedList = new StringList();
      new HashMap();
      Map childofDrawing = null;
      StringList slDrawingChildBusId = getObjectDetailList((String)rootMap.get("to[Associated Drawing].from.id"));
      slDrgConnObjType = (String)rootMap.get("to[Associated Drawing].from.type");
      printTrace("EDAT_DB_Analyser : analyser: analyzeCATDrawing : slDrawingChildBusId: " + slDrawingChildBusId);
      printTrace("EDAT_DB_Analyser : analyser: analyzeCATDrawing : slDrgConnObjType: " + slDrgConnObjType);
      if (slDrgConnObjType != null && slDrgConnObjType.length() > 0 && slDrawingChildBusId != null && slDrawingChildBusId.size() > 0) {
         if (slDrgConnObjType.equalsIgnoreCase("CATPart") && !this.allCATPartsBusId.contains(slDrawingChildBusId) || slDrgConnObjType.equalsIgnoreCase("CATProduct") && !this.allCATProductsBusId.contains(slDrawingChildBusId)) {
            mlProd = anlyserObj.getRootObjectDetails(context, slDrawingChildBusId, slDrgConnObjType, this.isSelectiveMode);
            childofDrawing = (Map)mlProd.get(0);
            this.iAssemblyLevel = 0;
            childofDrawing.put("level", Integer.toString(this.iAssemblyLevel));
            mlChildData.add(childofDrawing);
            printTrace("EDAT_DB_Analyser : analyser: analyzeCATDrawing : mlChildData: " + mlChildData);
            if (slDrgConnObjType.equalsIgnoreCase("CATProduct")) {
               mlChildData = this.analyzeNonImmediateTypes(context, childofDrawing, mlChildData, "", this.iAssemblyLevel, slChildProcessedList, slDrgConnObjType, type);
               Map mUpdateMap = this.levelUpdate(mlChildData, baseDir);
               mFillMap.putAll(mUpdateMap);
            } else {
               Iterator var16 = mlChildData.iterator();

               while(var16.hasNext()) {
                  Object obj = var16.next();
                  if (obj instanceof Map) {
                     Map<String, String> currentMap = (Map)obj;
                     String busId = (String)currentMap.get("id");
                     mFillMap.put(busId, currentMap);
                  }
               }
            }
         }
      } else {
         mFillMap.put(busId_temp, rootMap);
      }

      printTrace("EDAT_DB_Analyser : analyser: analyzeCATDrawing : mFillMap: " + mFillMap);
      printTrace("EDAT_DB_Analyser : analyser: analyzeCATDrawing ----> End of the method ");
      return mFillMap;
   }

   private void AddCATRecordsAndSendJobs() throws Exception {
      printTrace("EDAT_DB_Analyser : AddCATRecordsAndSendJobs ----> Start of the method");
      String filePath = "";
      StringList busIds = new StringList();
      String revPath = "";
      String outputFolder = objAnlayserConfig.getBaseDirectory();
      List<String> files = new ArrayList();
      int iRev;
      Object analyserPartsList;
      int tempCount;
      int iCount;
      String Exporttypename;
      StringList ExportPath_CATDrawing_List;
      if (this.allCATPartsBusId != null || !this.allCATPartsBusId.isEmpty()) {
         iRev = 0;

         for(analyserPartsList = new ArrayList(); iRev < 2; ++iRev) {
            ((List)analyserPartsList).clear();
            this.fileCount = 0;
            if (iRev == 0) {
               filePath = objAnlayserConfig.getBaseDirectory() + "/" + "CATPart" + "_FirstRev.txt";
               analyserPartsList = this.firstRevParts;
               revPath = "FirstRev";
            } else {
               filePath = objAnlayserConfig.getBaseDirectory() + "/" + "CATPart" + "_RestRev.txt";
               revPath = "RestRev";
               analyserPartsList = this.restRevParts;
            }

            this.writeAnalysedFile((List)analyserPartsList, filePath);
            filePath = objAnlayserConfig.getBaseDirectory() + "\\" + "CATPart" + "\\" + revPath + "\\" + "CATPart" + "_" + "0" + "\\" + this.fileCount;
            tempCount = 0;

            for(iCount = 0; iCount < ((List)analyserPartsList).size(); ++iCount) {
               busIds.add(((List)analyserPartsList).get(iCount));
               ++tempCount;
               if (!((double)tempCount < this.threshold) || iCount == ((List)analyserPartsList).size() - 1) {
                  this.writeToFileAndSendJob(filePath, busIds);
                  Exporttypename = "CATPart".replaceAll(" ", "_");
                  ExportPath_CATDrawing_List = this.ExportPathList;
                  this.writeAnalysedFile(ExportPath_CATDrawing_List, this.Exportpathtxt + Exporttypename + ".txt");
                  busIds.clear();
                  tempCount = 0;
               }
            }
         }
      }

      this.ExportPathList.clear();
      if (this.allCATProductsBusId != null || !this.allCATProductsBusId.isEmpty()) {
         new ArrayList();
         Map<Integer, HashMap> sLevel = new HashMap();
         iRev = 0;

         while(iRev < 2) {
            ((Map)sLevel).clear();
            this.fileCount = 0;
            List analyzedCATProducts;
            if (iRev == 0) {
               filePath = objAnlayserConfig.getBaseDirectory() + "/" + "CATProduct" + "_FirstRev.txt";
               sLevel = this.firstRevLevel;
               analyzedCATProducts = this.firstRevProducts;
               revPath = "FirstRev";
            } else if (iRev != 0) {
               filePath = objAnlayserConfig.getBaseDirectory() + "/" + "CATProduct" + "_RestRev.txt";
               sLevel = this.restRevLevel;
               analyzedCATProducts = this.restRevProducts;
               revPath = "RestRev";
            }

            printTrace("EDAT_DB_Analyser :  AddCATRecordsAndSendJobs : Selective Mode : sLevel--->" + sLevel);
            printTrace("EDAT_DB_Analyser :  AddCATRecordsAndSendJobs : Selective Mode : Writing CATProductFirstRev.txt done--->");
            this.baseFolder = objAnlayserConfig.getBaseDirectory() + "\\" + "CATProduct" + "\\" + revPath;
            if (!((Map)sLevel).isEmpty() && ((Map)sLevel).size() >= 1) {
               if (((Map)sLevel).containsKey(0)) {
                  HashMap<String, List<String>> CATRootProducts = (HashMap)((Map)sLevel).get(0);
                  List<String> analyzedCATRootProducts = (List)CATRootProducts.get("CATProduct");
                  this.writeAnalysedFile(analyzedCATRootProducts, filePath);
               }

               Iterator var19 = ((Map)sLevel).entrySet().iterator();

               while(var19.hasNext()) {
                  Entry<Integer, HashMap> entry = (Entry)var19.next();
                  Integer outerKey = (Integer)entry.getKey();
                  HashMap<String, List<String>> innerMap = (HashMap)entry.getValue();
                  outputFolder = this.baseFolder + "\\" + "CATProduct" + "_" + outerKey.toString();
                  if (!files.contains(outputFolder)) {
                     files.add(outputFolder);
                  }
               }

               printTrace("EDAT_DB_Analyser :  AddCATRecordsAndSendJobs : Selective Mode : files--->" + files);
               this.writeAnalysedProdToFiles(files, (Map)sLevel);
               this.sendJobsToActiveMQ(this.baseFolder);
               ++this.fileCount;
            } else {
               printTrace("slevel is empty");
            }

            ++iRev;
            files.clear();
         }

         String Exporttypename = "CATProduct".replaceAll(" ", "_");
         Set<String> uniquePaths = new HashSet(this.ExportPathList);
         List<String> ExportPath_CATProducts_List = new ArrayList(uniquePaths);
         this.writeAnalysedFile(ExportPath_CATProducts_List, this.Exportpathtxt + Exporttypename + ".txt");
         ++this.fileCount;
      }

      this.ExportPathList.clear();
      if (this.AnalyzeCATDrawings != null || !this.AnalyzeCATDrawings.isEmpty()) {
         iRev = 0;

         for(analyserPartsList = new ArrayList(); iRev < 2; ++iRev) {
            ((List)analyserPartsList).clear();
            this.fileCount = 0;
            if (iRev == 0) {
               filePath = objAnlayserConfig.getBaseDirectory() + "/" + "CATDrawing" + "_FirstRev.txt";
               analyserPartsList = this.firstRevDrawing;
               revPath = "FirstRev";
            } else {
               filePath = objAnlayserConfig.getBaseDirectory() + "/" + "CATDrawing" + "_RestRev.txt";
               revPath = "RestRev";
               analyserPartsList = this.restRevDrawing;
            }

            this.writeAnalysedFile((List)analyserPartsList, filePath);
            filePath = objAnlayserConfig.getBaseDirectory() + "\\" + "CATDrawing" + "\\" + revPath + "\\" + "CATDrawing" + "_" + "0" + "\\" + this.fileCount;
            tempCount = 0;

            for(iCount = 0; iCount < ((List)analyserPartsList).size(); ++iCount) {
               busIds.add(((List)analyserPartsList).get(iCount));
               ++tempCount;
               if (!((double)tempCount < this.threshold) || iCount == ((List)analyserPartsList).size() - 1) {
                  this.writeToFileAndSendJob(filePath, busIds);
                  Exporttypename = "CATDrawing".replaceAll(" ", "_");
                  ExportPath_CATDrawing_List = this.ExportPathList;
                  this.writeAnalysedFile(ExportPath_CATDrawing_List, this.Exportpathtxt + Exporttypename + ".txt");
                  busIds.clear();
                  tempCount = 0;
               }
            }
         }

         this.ExportPathList.clear();
      }

      printTrace("EDAT_DB_Analyser : AddCATRecordsAndSendJobs ----> End of the method");
   }
}
