package com.edatanalyser.services;

import com.matrixone.apps.framework.ui.UIUtil;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

public class EDAT_DateComparator implements Comparator<String> {
   public String UTC_DATE_FORMAT = "MM/dd/yyyy hh:mm:ss a";

   public int compare(String o1, String o2) {
      if (UIUtil.isNotNullAndNotEmpty(o1) && UIUtil.isNotNullAndNotEmpty(o2)) {
         try {
            Date date1 = this.extractDate(o1);
            Date date2 = this.extractDate(o2);
            if (date1.equals(date2)) {
               return 0;
            }

            if (date1.before(date2)) {
               return -1;
            }

            return 1;
         } catch (ParseException var5) {
            System.out.println("EDAT_DateComparator : Exception while comparing date1 and date2 ----> :" + var5.getMessage());
         }
      }

      return 0;
   }

   private Date extractDate(String line) throws ParseException {
      String[] arrInput = new String[line.length()];
      if (line.contains("|")) {
         arrInput = line.split("\\|");
      } else {
         arrInput = line.split(",");
      }

      if (arrInput.length >= 5) {
         String originated = UIUtil.isNotNullAndNotEmpty(arrInput[5]) ? arrInput[5].trim() : "";
         Date date1 = (new SimpleDateFormat(this.UTC_DATE_FORMAT)).parse(originated);
         return date1;
      } else {
         return null;
      }
   }
}
