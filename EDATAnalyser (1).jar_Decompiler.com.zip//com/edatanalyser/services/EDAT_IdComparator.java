package com.edatanalyser.services;

import com.matrixone.apps.framework.ui.UIUtil;
import java.text.ParseException;
import java.util.Comparator;

public class EDAT_IdComparator implements Comparator<String> {
   public int compare(String o1, String o2) {
      if (UIUtil.isNotNullAndNotEmpty(o1) && UIUtil.isNotNullAndNotEmpty(o2)) {
         try {
            String id1 = this.extractID(o1);
            String id2 = this.extractID(o2);
            if (id1.equals(id2)) {
               return 0;
            }

            if (id1.compareTo(id2) < 0) {
               return -1;
            }

            return 1;
         } catch (ParseException var5) {
            System.out.println("EDAT_IdComparator : ParseException while comparing id1 and id2 : " + var5.getMessage());
         }
      }

      return 0;
   }

   private String extractID(String line) throws ParseException {
      String[] arrInput = line.split("\\|");
      if (arrInput.length >= 6) {
         String strObjectId = UIUtil.isNotNullAndNotEmpty(arrInput[6]) ? arrInput[6].trim() : "";
         return strObjectId;
      } else {
         return null;
      }
   }
}
