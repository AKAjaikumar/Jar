package com.edatanalyser.services;

import com.edatxflowlogger.XFlowLogger;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import matrix.db.Context;
import matrix.util.StringList;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class EDAT_DBService extends EDAT_AnalyserUtils {
   private Connection connection = null;
   private XFlowLogger xFlowLogger;
   private String userId;
   private String password;
   private String connectionUrl;
   private String dbType;

   public EDAT_DBService() {
      this.xFlowLogger = EDAT_DB_Analyser.xMLLogger;
      this.userId = null;
      this.password = null;
      this.connectionUrl = null;
      this.dbType = null;
   }

   public void setUserID(String userId) {
      this.userId = userId;
   }

   public String getUserID() {
      return this.userId;
   }

   public void setPassword(String password) {
      this.password = password;
   }

   public String getPassword() {
      return this.password;
   }

   public void setConnectionUrl(String connectionUrl) {
      this.connectionUrl = connectionUrl;
   }

   public String getConnectionUrl() {
      return this.connectionUrl;
   }

   public void setDBType(String dbType) {
      this.dbType = dbType;
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : setDBType : dbType --->  " + dbType);
   }

   public String getDBType() {
      return this.dbType;
   }

   public Connection getConnection() {
      return this.connection;
   }

   public void setConnection(Connection connection) {
      this.connection = connection;
   }

   public void connectToDB() throws Exception {
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : connectToDB : start ");

      try {
         String serverName = null;
         String dbName = null;
         String port = null;
         String serviceName = null;
         Document doc = this.readDBConfigXMLDoc();
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : connectToDB : doc --->  " + doc);
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : connectToDB : doc --->  " + doc);
         this.setDBType(this.getParamaterValueFromXML(doc, "DBType"));
         String connectionString = this.getParamaterValueFromXML(doc, "ConnectionString");
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : connectToDB : connectionString --->  " + connectionString);
         this.setUserID(this.getParamFromConnectionString(connectionString, "User ID"));
         this.setPassword(this.getParamFromConnectionString(connectionString, "Password"));
         loggedXflow(this.xFlowLogger, "OK", "DB Type", this.dbType);
         if ("MSSQL".equalsIgnoreCase(this.dbType)) {
            serverName = this.getParamFromConnectionString(connectionString, "Data Source");
            dbName = this.getParamFromConnectionString(connectionString, "Initial Catalog");
            this.setConnectionUrl("jdbc:sqlserver://" + serverName + ";databaseName=" + dbName);
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
         } else if ("Oracle".equalsIgnoreCase(this.dbType)) {
            serverName = this.getParamFromConnectionString(connectionString, "HOST");
            port = this.getParamFromConnectionString(connectionString, "PORT");
            serviceName = this.getParamFromConnectionString(connectionString, "SERVICE_NAME");
            this.setConnectionUrl("jdbc:oracle:thin:@" + serverName + ":" + port + ":" + serviceName);
            Class.forName("oracle.jdbc.OracleDriver");
         }

         this.setConnection(DriverManager.getConnection(this.getConnectionUrl(), this.getUserID(), this.getPassword()));
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : connectToDB :getConnection() --->  " + this.getConnection());
         if (this.getConnection() != null) {
            loggedXflowGlobalStatus(this.xFlowLogger, "OK", "connection to DB Successful");
         }
      } catch (Exception var7) {
         loggedXflowGlobalStatus(this.xFlowLogger, "KO", "connection to DB Failed " + var7.getMessage());
         throw new Exception("EDAT_DB_Analyser : Connection to DB Failed");
      }

      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : connectToDB : done");
   }

   public Map<String, List<String>> getDetailsFromTable(Context context) throws Exception {
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getDetailsFromTable ----> start");
      Map<String, List<String>> map = new HashMap();
      Statement stmt = null;
      String query = "select BUS_ID,MODIFICATION_DATE,STATUS from IMPORT_DATA";
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getDetailsFromTable : query----> " + query);

      try {
         this.connectToDB();
         stmt = this.getConnection().createStatement();
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getDetailsFromTable : stmt----> " + stmt);
         ResultSet rs = stmt.executeQuery(query);
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getDetailsFromTable : rs----> " + rs);

         while(rs.next()) {
            String modificationDate = rs.getString("MODIFICATION_DATE");
            String status = rs.getString("STATUS");
            List<String> tempList = new StringList();
            tempList.add(modificationDate);
            tempList.add(status);
            map.put(rs.getString("BUS_ID"), tempList);
         }
      } catch (SQLException var12) {
         loggedXflowGlobalStatus(this.xFlowLogger, "KO", "Getting details from DB table failed " + var12.getMessage());
         throw new SQLException("EDAT_DB_Analyser : Getting details from DB table failed");
      } finally {
         if (stmt != null) {
            stmt.close();
         }

      }

      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getDetailsFromTable : map----> " + map);
      return map;
   }

   public void deleteCloudFailedFromTable(String strUniqueId) throws SQLException {
      try {
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : deleteCloudFailedFromTable : Start of the method");
         PreparedStatement ps = this.getConnection().prepareStatement("delete from IMPORT_DATA where ID = ?");
         ps.setString(1, strUniqueId);
         ps.executeUpdate();
         this.getConnection().commit();
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : deleteCloudFailedFromTable : End of the method");
      } catch (SQLException var3) {
         loggedXflowGlobalStatus(this.xFlowLogger, "KO", " deleteCloudFailedFromTable method failed " + var3.getMessage());
         throw new SQLException("EDAT_DB_Analyser : deleteCloudFailedFromTable method failed");
      }
   }

   public Document readDBConfigXMLDoc() throws Exception {
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : readDBConfigXMLDoc : start ");
      Document doc = null;

      try {
         String path = EDAT_DB_Analyser.objAnlayserConfig.getDecodedPropertiesPath() + File.separator + "config" + File.separator + "dbConfig.xml";
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : readDBConfigXMLDoc : path ---> " + path);
         File file = new File(path);
         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         DocumentBuilder builder = factory.newDocumentBuilder();
         doc = builder.parse(file);
         doc.getDocumentElement().normalize();
      } catch (Exception var6) {
         loggedXflowGlobalStatus(this.xFlowLogger, "KO", "Not able to read dbconfig.xml " + var6.getMessage());
         throw new Exception("EDAT_DB_Analyser : Not able to read dbconfig.xml");
      }

      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : readDBConfigXMLDoc : doc ---> " + doc);
      return doc;
   }

   public String getParamaterValueFromXML(Document doc, String tagName) {
      String nodeValue = null;

      try {
         NodeList nodeList = doc.getElementsByTagName(tagName);

         for(int i = 0; i < nodeList.getLength(); ++i) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == 1) {
               nodeValue = node.getTextContent();
            }
         }
      } catch (Exception var7) {
         var7.getMessage();
      }

      return nodeValue;
   }

   public String getParamFromConnectionString(String paramValue, String attrName) {
      paramValue = paramValue.substring(paramValue.indexOf(attrName));
      if (this.getDBType().equalsIgnoreCase("Oracle")) {
         if (!attrName.equals("User ID") && !attrName.equals("Password")) {
            paramValue = paramValue.substring(0, paramValue.indexOf(")"));
         } else {
            paramValue = paramValue.substring(0, paramValue.indexOf(";"));
         }
      }

      if (this.getDBType().equalsIgnoreCase("MSSQL")) {
         paramValue = paramValue.substring(0, paramValue.indexOf(";"));
      }

      paramValue = paramValue.split("=")[1];
      return paramValue;
   }

   public void closeConnection() throws SQLException {
      this.getConnection().close();
   }
}
